// ignore_for_file: prefer_const_constructors

import 'dart:async';

import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:minors/RecordMissingDetails.dart';
//import 'package:minors/RecordMissing777.dart';
import 'package:minors/main.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import 'RecordMissing.dart';
import 'connectToDBCode.dart';
import 'contactus.dart';
import 'exit.dart';
import 'profile.dart';
import 'royalOrder.dart';
import 'userPage.dart';

const List<String> firstList = <String>[
  '...اختر...',
];

const List<String> yearsList = <String>[
  '...اختر...',
  '2015',
  '2016',
  '2017',
  '2018',
  '2019',
  '2020',
  '2021',
  '2022',
];

const List<String> notiTypeList = <String>[
  '...اختر...',
  'تحويل نقدي',
  'افصاح ',
];

String? department;
String? year;
String? notiType;
String? transferNum;
String? transferAmount;
String? transferedToDep;
String? note;

File? uploadedImage;
String? moneyTransfer;

int numOfRows = 0;

class RecordMissing2 extends StatelessWidget {
  // This widget is the root of your application.
  //

  RecordMissing2(
    notes,
    varDepartment,
  );

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Stateful Clicker Counter',
      theme: ThemeData(
        // Application theme data, you can set the colors for the application as
        // you want
        primarySwatch: Colors.grey,
      ),
      home: MyHomePage(title: 'Flutter Demo Clicker Counter Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final String title;
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<ParseObject> results = <ParseObject>[];
  final GlobalKey<FormState> _Formkey = GlobalKey<FormState>();
  //bool isVisible = false;

  final todoController = TextEditingController();
  final todoControllerNote = TextEditingController();
  final todoControllerTransferAmount = TextEditingController();
  final todoControllerTransferNum = TextEditingController();

  //List<ParseObject> results = <ParseObject>[];
  String dropdownValue = '...اختر...';
  String dropdownValue2 = '...اختر...';
  String dropdownValue3 = '...اختر...';
  String dropdownValue4 = '...اختر...';
  String dropdownValue5 = '...اختر...';
  String dropdownValue6 = '...اختر...';
  String dropdownValue7 = '...اختر...';

  //String dropdownValue = yearsList.first;
  List<ParseObject?> dropdownItems = <ParseObject?>[];

  FilePickerResult? result;
  String? _fileName;
  PlatformFile? pickedFile;
  bool isLoading = false;
  File? fileToDisplay;
  bool isVisible = true;
  //final GlobalKey<FormState> _Formkey = GlobalKey<FormState>();
  //

  void readData() async {
    var apiResponse = await ParseObject('Todo').getAll();
    if (apiResponse.success) {
      for (var myObject in apiResponse.result) {
        debugPrint(" OBJECT: " + myObject.get<String>('Department')!);
        print("yay ");
        dropdownItems.add(myObject);
      }
      setState(() {});
    } else {
      print("can't connect to DB ");
    }
    @override
    void initState() {
      super.initState();
      readData();
      print("barb is kokay");
    }
  }

  void PickFile() async {
    try {
      setState(() {
        isLoading = true;
      });

      result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['png', 'pdf', 'jpg', 'xlsx'],
        allowMultiple: false,
      );

      if (result != null) {
        _fileName = result!.files.first.name;
        pickedFile = result!.files.first;
        fileToDisplay = File(pickedFile!.path.toString());

        print("FileName: $_fileName");
      }
      setState(() {
        isLoading = false;
      });
    } catch (e) {
      print(e);
    }
  }

  void addToDo() async {
    if (todoController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Empty title"),
        duration: Duration(seconds: 2),
      ));
      return;
    }
    await saveTodo(todoController.text);
    setState(() {
      todoController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    // String emailFirst = "munaif.abdulaziz@wilayah.gov.sa";
    // String secondEmail = "anqari.sulaiman@wilayah.gov.sa";
    // String thirdEmail = "alharby.abdulaziz@wilayah.gov.sa";
    double widthSize = MediaQuery.of(context).size.width;
    double heightSize = MediaQuery.of(context).size.height;
    String selectText = "اختر";

    return Scaffold(
        backgroundColor: Color(0xf2f6f4f4),
        body: Container(
            height: 622,
            child: Scaffold(
              backgroundColor: Color(0xf2f6f4f4),
              body: Padding(
                padding: const EdgeInsets.all(12),
                child: CustomScrollView(slivers: [
                  SliverAppBar(
                    pinned: true,
                    backgroundColor: Colors.white,
                    //Color(0xff493636),
                    //Color(0xffb4b0b3),
                    foregroundColor: Colors.black,
                    leadingWidth: 72,
                    title: Center(child: Text("المفقودات")),
                    leading: Padding(
                      padding: const EdgeInsets.only(left: 0.8),
                      child: IconButton(
                        icon: Icon(
                          Icons.person,
                          color: Color(0xff000000),
                          size: 30.0,
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => Profile()),
                          );
                        },
                      ),
                    ),
                  ),

                  /// here
                  /// here
                  /// here

                  //here
                  // here
                  // here
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //here
                  //here
                  SliverToBoxAdapter(
                    child: Form(
                      child: Container(
                        margin: EdgeInsets.only(top: 22),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(
                          topRight: Radius.circular(73),
                          topLeft: Radius.circular(13),
                          bottomRight: Radius.circular(73),
                          bottomLeft: Radius.circular(13),
                        )),
                        width: widthSize,
                        child: Column(
                          // fit: StackFit.passthrough,
                          //alignment: Alignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: widthSize,
                              // height: 588,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.only(
                                  topRight: Radius.circular(23),
                                  topLeft: Radius.circular(23),
                                  bottomLeft: Radius.circular(0),
                                  bottomRight: Radius.circular(0),
                                ),
                              ),
                              // color: Colors.white,
                            ),

                            // above is the end of the first muliti Select Field row container
                            // above is the end of the last muliti Select Field  row container
                            //
                            //
                            //
                            /// body white container starts here
                            Container(
                              color: Colors.white,
                              padding: EdgeInsets.all(17),
                              width: widthSize - 35,
                              child: Column(
                                children: [
                                  ///
                                  ///
                                  ///
                                  ///
                                  ///

                                  Container(
                                    margin: EdgeInsets.all(12),
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      "الجهة",
                                      textDirection: TextDirection.rtl,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 17,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  // DropdownButton below
                                  // DropdownButton below
                                  // DropdownButton below
                                  Directionality(
                                    textDirection: TextDirection.rtl,
                                    child: Container(
                                      alignment: Alignment.center,
                                      // margin: EdgeInsets.only(top: 7),
                                      width: widthSize - 68,
                                      decoration: BoxDecoration(
                                        color: Color(0xffe8e8e8),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(27),
                                          topLeft: Radius.circular(27),
                                          bottomLeft: Radius.circular(27),
                                          bottomRight: Radius.circular(27),
                                        ),
                                      ),
                                      child: Text('$dropdownItems'),
                                      /*
                                      DropdownButton<String>(
                                        // Step 3.

                                        value: dropdownValue,
                                        onChanged: (String? value) {
                                          setState(() {
                                            dropdownValue = value!;
                                            department = dropdownValue;
                                            print(dropdownValue);
                                          });
                                        },
                                        // Step 4.
                                        items:
                                            //varDepartment2!

                                            <String>[
                                          '...اختر...',
                                          ' "الأمن العام  "المرور',
                                        ]

                                                // notiTypeList
                                                .map<DropdownMenuItem<String>>(
                                                    (String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Container(
                                              margin:
                                                  EdgeInsets.only(right: 122),
                                              child: Text(
                                                value,
                                                style: TextStyle(fontSize: 17),
                                              ),
                                            ),
                                          );
                                        }).toList(),
                                      ),
                                      */
                                    ),
                                  ),
                                  // notes row is below //
                                  // // notes row is below
                                  // // notes row is below
                                  // // notes row is below
                                  // // notes row is below
                                  // // notes row is below
                                  //
                                  Container(
                                    margin: EdgeInsets.all(12),
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      "السنة",
                                      textDirection: TextDirection.rtl,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 17,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  Directionality(
                                    textDirection: TextDirection.rtl,
                                    child: Container(
                                      alignment: Alignment.center,
                                      // margin: EdgeInsets.only(top: 7),
                                      width: widthSize - 68,
                                      decoration: BoxDecoration(
                                        color: Color(0xffe8e8e8),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(27),
                                          topLeft: Radius.circular(27),
                                          bottomLeft: Radius.circular(27),
                                          bottomRight: Radius.circular(27),
                                        ),
                                      ),
                                      child: DropdownButton<String>(
                                        // Step 3.

                                        value: dropdownValue2,
                                        onChanged: (String? value2) {
                                          setState(() {
                                            dropdownValue2 = value2!;
                                            year = dropdownValue2;
                                            print(dropdownValue2);
                                          });
                                        },
                                        // Step 4.
                                        items:
                                            //varDepartment2!

                                            <String>[
                                          '...اختر...',
                                          '2015',
                                          '2016',
                                          '2017',
                                          '2018                    ',
                                          '2019',
                                          '2020',
                                          '2021',
                                          '2022',
                                        ]

                                                // yearsList
                                                .map<DropdownMenuItem<String>>(
                                                    (String value2) {
                                          return DropdownMenuItem<String>(
                                            value: value2,
                                            child: Container(
                                              margin:
                                                  EdgeInsets.only(right: 122),
                                              child: Text(
                                                value2,
                                                style: TextStyle(fontSize: 17),
                                              ),
                                            ),
                                          );
                                        }).toList(),
                                      ),
                                    ),
                                  ),

                                  ///  /// amount ends here
                                  ///  /// amount ends here
                                  ///
/*
                                  Container(
                                    height: 255,
                                    width: 255,
                                    color: Colors.red,
                                    child: DropdownButton<String>(
                                        items: ['lol', 'ggg'],
                                        
                                        dropdownItems
                                            .map((ParseObject? value) {
                                          return DropdownMenuItem<String>(
                                            value: value!
                                                .get<String>("Department")!,
                                            child: Text(value
                                                .get<String>("Department")!),
                                          );
                                        }).toList(),
                                         onChanged: (_) {}),
                                  ),
                                  */

                                  // notes row is below //
                                  // // notes row is below
                                  // // notes row is below
                                  // // notes row is below
                                  // // notes row is below
                                  // // notes row is below

                                  Container(
                                    margin: EdgeInsets.all(12),
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      "نوع الاشعار",
                                      textDirection: TextDirection.rtl,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 17,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),

                                  Directionality(
                                    textDirection: TextDirection.rtl,
                                    child: Container(
                                      alignment: Alignment.center,
                                      // margin: EdgeInsets.only(top: 7),
                                      width: widthSize - 68,
                                      decoration: BoxDecoration(
                                        color: Color(0xffe8e8e8),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(27),
                                          topLeft: Radius.circular(27),
                                          bottomLeft: Radius.circular(27),
                                          bottomRight: Radius.circular(27),
                                        ),
                                      ),
                                      child: DropdownButton<String>(
                                        // Step 3.

                                        value: dropdownValue3,
                                        onChanged: (String? value3) {
                                          setState(() {
                                            dropdownValue3 = value3!;
                                            notiType = value3;
                                            print("here " + dropdownValue3);
                                          });
                                        },
                                        // Step 4.
                                        items:
                                            //varDepartment2!

                                            <String>[
                                          '...اختر...',
                                          'تحويل نقدي',
                                          'افصاح عن سنوات سابقة',
                                        ]

                                                // yearsList
                                                .map<DropdownMenuItem<String>>(
                                                    (String value3) {
                                          return DropdownMenuItem<String>(
                                            value: value3,
                                            child: Container(
                                              margin:
                                                  EdgeInsets.only(right: 122),
                                              child: Text(
                                                value3,
                                                style: TextStyle(fontSize: 17),
                                              ),
                                            ),
                                          );
                                        }).toList(),
                                      ),
                                    ),
                                  ),

                                  if (notiType == "تحويل نقدي")
                                    Container(
                                      padding: EdgeInsets.all(17),
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        "  رقم الحوالة ",
                                        textDirection: TextDirection.rtl,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  if (notiType == "تحويل نقدي")
                                    Container(
                                      alignment: Alignment.center,
                                      // margin: EdgeInsets.only(top: 7),
                                      width: widthSize - 68,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Colors.transparent,
                                          width: 0.7,
                                        ),
                                        color: Colors.white,
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(27),
                                          topLeft: Radius.circular(27),
                                          bottomLeft: Radius.circular(17),
                                          bottomRight: Radius.circular(17),
                                        ),
                                      ),
                                      child: TextFormField(
                                        controller: todoControllerTransferNum,
                                        onChanged: (value4) {
                                          setState(() {
                                            print(value4);
                                            value4 =
                                                todoControllerTransferNum.text;
                                            transferNum = value4;
                                            print("kooooooooooo");
                                          });
                                          print(value4 + "stay awesome ");
                                        },
                                        textAlign: TextAlign.center,
                                        textDirection: TextDirection.rtl,
                                        decoration: InputDecoration(
                                            alignLabelWithHint: true,
                                            border: OutlineInputBorder(
                                              borderRadius: BorderRadius.only(
                                                topRight: Radius.circular(17),
                                                topLeft: Radius.circular(17),
                                                bottomLeft: Radius.circular(17),
                                                bottomRight:
                                                    Radius.circular(17),
                                              ),
                                            ),
                                            labelText: 'الرقم',
                                            labelStyle: TextStyle()),
                                      ),
                                    ),

                                  if (notiType == "تحويل نقدي")
                                    Container(
                                      padding: EdgeInsets.all(17),
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        "  مبلغ الحوالة ",
                                        textDirection: TextDirection.rtl,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  if (notiType == "تحويل نقدي")
                                    Container(
                                      alignment: Alignment.center,
                                      // margin: EdgeInsets.only(top: 7),
                                      width: widthSize - 68,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Colors.transparent,
                                          width: 0.7,
                                        ),
                                        color: Colors.white,
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(27),
                                          topLeft: Radius.circular(27),
                                          bottomLeft: Radius.circular(17),
                                          bottomRight: Radius.circular(17),
                                        ),
                                      ),
                                      child: TextFormField(
                                        controller:
                                            todoControllerTransferAmount,
                                        onChanged: (value5) {
                                          setState(() {
                                            print(value5);
                                            value5 =
                                                todoControllerTransferAmount
                                                    .text;
                                            transferAmount = value5;
                                            print("kooooooooooo");
                                          });
                                          print(value5 + "stay awesome ");
                                        },
                                        textAlign: TextAlign.center,
                                        textDirection: TextDirection.rtl,
                                        decoration: InputDecoration(
                                            alignLabelWithHint: true,
                                            border: OutlineInputBorder(
                                              borderRadius: BorderRadius.only(
                                                topRight: Radius.circular(17),
                                                topLeft: Radius.circular(17),
                                                bottomLeft: Radius.circular(17),
                                                bottomRight:
                                                    Radius.circular(17),
                                              ),
                                            ),
                                            labelText: 'تحويل نقدي',
                                            labelStyle: TextStyle()),
                                      ),
                                    ),

                                  if (notiType == "تحويل نقدي")
                                    Container(
                                      padding: EdgeInsets.all(17),
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        "  الجهة المحول لها المبلغ  ",
                                        textDirection: TextDirection.rtl,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),

                                  if (notiType == "تحويل نقدي")
                                    Directionality(
                                      textDirection: TextDirection.rtl,
                                      child: Container(
                                        alignment: Alignment.center,
                                        // margin: EdgeInsets.only(top: 7),
                                        //width: widthSize - 173,
                                        decoration: BoxDecoration(
                                          color: Color(0xffe8e8e8),
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(27),
                                            topLeft: Radius.circular(27),
                                            bottomLeft: Radius.circular(27),
                                            bottomRight: Radius.circular(27),
                                          ),
                                        ),
                                        child: DropdownButton<String>(
                                          // Step 3.

                                          value: dropdownValue7,
                                          onChanged: (String? value6) {
                                            setState(() {
                                              dropdownValue7 = value6!;
                                              transferedToDep = value6;
                                              print(
                                                  "here is dep to transfer to " +
                                                      transferedToDep!);
                                            });
                                          },
                                          // Step 4.
                                          items:
                                              //varDepartment2!

                                              <String>[
                                            '...اختر...',
                                            'الهيئة العامه للولاية',
                                          ]

                                                  // yearsList
                                                  .map<
                                                          DropdownMenuItem<
                                                              String>>(
                                                      (String value6) {
                                            return DropdownMenuItem<String>(
                                              value: value6,
                                              child: Container(
                                                margin:
                                                    EdgeInsets.only(right: 122),
                                                child: Text(
                                                  value6,
                                                  style:
                                                      TextStyle(fontSize: 17),
                                                ),
                                              ),
                                            );
                                          }).toList(),
                                        ),
                                      ),
                                    ),

                                  Container(
                                    padding: EdgeInsets.all(17),
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      "  ملاحظات ",
                                      textDirection: TextDirection.rtl,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 17,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),

                                  Container(
                                    alignment: Alignment.center,
                                    // margin: EdgeInsets.only(top: 7),
                                    width: widthSize - 68,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        color: Colors.transparent,
                                        width: 0.7,
                                      ),
                                      color: Colors.white,
                                      borderRadius: BorderRadius.only(
                                        topRight: Radius.circular(27),
                                        topLeft: Radius.circular(27),
                                        bottomLeft: Radius.circular(17),
                                        bottomRight: Radius.circular(17),
                                      ),
                                    ),
                                    child: TextFormField(
                                      controller: todoControllerNote,
                                      onChanged: (value7) {
                                        setState(() {
                                          print(value7);
                                          value7 = todoControllerNote.text;
                                          note = value7;
                                          print("kooooooooooo");
                                        });
                                        print(value7 +
                                            " This is the note TextField ");
                                      },
                                      textAlign: TextAlign.center,
                                      textDirection: TextDirection.rtl,
                                      decoration: InputDecoration(
                                          alignLabelWithHint: true,
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(17),
                                              topLeft: Radius.circular(17),
                                              bottomLeft: Radius.circular(17),
                                              bottomRight: Radius.circular(17),
                                            ),
                                          ),
                                          labelText: 'ملاحظات',
                                          labelStyle: TextStyle()),
                                    ),
                                  ),

                                  /// notes ends here
                                  ///  /// notes ends here
                                  ///  /// notes ends here

                                  // below is the start of the TextButton to upload files
                                  // below is the start of the TextButton to upload files
                                  // below is the start of the TextButton to upload files

                                  Container(
                                    margin: EdgeInsets.only(
                                        left: 7, right: 7, top: 22),
                                    padding: EdgeInsets.only(left: 7, right: 7),
                                    child: isLoading
                                        ? CircularProgressIndicator()
                                        : TextButton(
                                            onPressed: () {
                                              PickFile();
                                            },
                                            child: Column(
                                              children: [
                                                Container(
                                                  alignment:
                                                      Alignment.centerRight,
                                                  width: widthSize + 77,
                                                  padding: EdgeInsets.only(
                                                    top: 7,
                                                    bottom: 7,
                                                  ),
                                                  child: Text(
                                                    "(img,excel,pdf) حجم الملف 20 ميجا بايت وبصيغة ",
                                                    style: TextStyle(
                                                        color: Colors.black),
                                                  ),
                                                ),
                                                Container(
                                                    decoration: BoxDecoration(
                                                      border: Border.all(
                                                        color: Colors.grey,
                                                        width: 0.7,
                                                      ),
                                                      color: Color(0xff038447),
                                                      borderRadius:
                                                          BorderRadius.only(
                                                        topRight:
                                                            Radius.circular(17),
                                                        topLeft:
                                                            Radius.circular(17),
                                                        bottomLeft:
                                                            Radius.circular(17),
                                                        bottomRight:
                                                            Radius.circular(17),
                                                      ),
                                                    ),
                                                    padding: EdgeInsets.only(
                                                      left: 7,
                                                      right: 17,
                                                    ),
                                                    margin: EdgeInsets.only(
                                                      left: 17,
                                                      right: 17,
                                                    ),
                                                    height: 37,
                                                    width: 197,
                                                    alignment: Alignment.center,
                                                    // color: Color(0xff038447),
                                                    child: Row(
                                                      children: [
                                                        Text(
                                                          "No File is...",
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                        Container(
                                                          color: Colors.white,
                                                          margin:
                                                              EdgeInsets.only(
                                                            top: 1,
                                                            bottom: 1,
                                                            left: 3,
                                                            right: 3,
                                                          ),
                                                          width: 3,
                                                          child:
                                                              // if(pickedFile != null)
                                                              SizedBox(
                                                            height: 50,
                                                            width: 100,
                                                          ),
                                                        ),
                                                        Container(
                                                          padding:
                                                              EdgeInsets.only(
                                                            left: 17,
                                                            right: 3,
                                                          ),
                                                          child: Text(
                                                            "Choose File",
                                                            style: TextStyle(
                                                                color: Color(
                                                                    0xffa9a7a7)),
                                                          ),
                                                        ),
                                                      ],
                                                    )),
                                              ],
                                            ),
                                          ),
                                  ),
                                  if (pickedFile != null)
                                    Container(
                                      margin: EdgeInsets.all(7),
                                      padding: EdgeInsets.all(7),
                                      child: SizedBox(
                                        height: 50,
                                        width: 100,
                                        child: Column(
                                          children: [
                                            Text(_fileName!),
                                            SizedBox(height: 7),
                                            Image.file(fileToDisplay!),
                                          ],
                                        ),
                                      ),
                                    ),

                                  Container(
                                    margin: EdgeInsets.only(
                                        left: 12, top: 22, bottom: 12),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                              height: 37,
                                              width: 62,
                                              decoration: BoxDecoration(
                                                border: Border.all(
                                                  color: Colors.grey,
                                                  width: 0.7,
                                                ),
                                                color: Color(0xff038447),
                                                borderRadius: BorderRadius.only(
                                                  topRight: Radius.circular(17),
                                                  topLeft: Radius.circular(17),
                                                  bottomLeft:
                                                      Radius.circular(17),
                                                  bottomRight:
                                                      Radius.circular(17),
                                                ),
                                              ),
                                              alignment: Alignment.center,
                                              margin: EdgeInsets.only(
                                                  top: 12, right: 12),
                                              //  color: Color(0xff038447),
                                              child: TextButton(
                                                  onPressed: () {},
                                                  child: Text(
                                                    "الغاء",
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ))),
                                          Container(
                                            height: 37,
                                            width: 62,
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                color: Colors.grey,
                                                width: 0.7,
                                              ),
                                              color: Color(0xff038447),
                                              borderRadius: BorderRadius.only(
                                                topRight: Radius.circular(17),
                                                topLeft: Radius.circular(17),
                                                bottomLeft: Radius.circular(17),
                                                bottomRight:
                                                    Radius.circular(17),
                                              ),
                                            ),
                                            alignment: Alignment.center,
                                            margin: EdgeInsets.only(top: 12),
                                            //color: Color(0xff038447),
                                            child: TextButton(
                                                onPressed: () async {
                                                  Future.delayed(
                                                      Duration(
                                                          milliseconds: 1000),
                                                      () {
                                                    // Do something

                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              RecordMissingBody()),
                                                    );
                                                  });

                                                  if (transferAmount != null &&
                                                      transferNum != null &&
                                                      _fileName != null) {
                                                    var firstObject =
                                                        ParseObject('Missings')
                                                          ..set('Department',
                                                              department)
                                                          ..set('Year', year)
                                                          ..set('FileName',
                                                              _fileName)
                                                          ..set(
                                                              'TransferNumber',
                                                              transferNum)
                                                          ..set(
                                                              'TranferToDepartmentName',
                                                              transferedToDep)
                                                          ..set(
                                                              'TransferAmount',
                                                              transferAmount)
                                                          ..set('NotiType',
                                                              notiType)
                                                          ..set('Notes', note);
                                                    await firstObject.save();
                                                    print('done ' + notiType!);
                                                  } else if (_fileName ==
                                                      null) {
                                                    var firstObject =
                                                        ParseObject('Missings')
                                                          ..set('Department',
                                                              department)
                                                          ..set('Year', year)
                                                          ..set('FileName',
                                                              '_fileName')
                                                          ..set(
                                                              'TransferNumber',
                                                              transferNum)
                                                          ..set(
                                                              'TranferToDepartmentName',
                                                              transferedToDep)
                                                          ..set(
                                                              'TransferAmount',
                                                              transferAmount)
                                                          ..set('NotiType',
                                                              notiType)
                                                          ..set('Notes', note);
                                                    await firstObject.save();
                                                  } else {
                                                    // _fileName
                                                    var firstObject =
                                                        ParseObject('Missings')
                                                          ..set('Department',
                                                              department)
                                                          ..set('Year', year)
                                                          ..set('FileName',
                                                              'fileToDisplay')
                                                          ..set(
                                                              'TransferNumber',
                                                              ' فارغ')
                                                          ..set(
                                                              'TranferToDepartmentName',
                                                              ' فارغ')
                                                          ..set(
                                                              'TransferAmount',
                                                              ' فارغ')
                                                          ..set('NotiType',
                                                              notiType)
                                                          ..set('Notes', note);
                                                    await firstObject.save();
                                                  }
                                                  if (!_Formkey.currentState!
                                                      .validate()) {
                                                    return;
                                                  }

                                                  Future.delayed(
                                                      Duration(
                                                          milliseconds: 3000),
                                                      () {
                                                    // Do something

                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              RecordMissingBody()),
                                                    );
                                                  });
                                                  setState(() {
                                                    //isVisible = !isVisible;
                                                  });
                                                },
                                                child: Text(
                                                  "حفظ",
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                )),
                                          ),
                                        ]),
                                  ),

                                  Container(
                                    margin: EdgeInsets.only(bottom: 12),
                                    child: TextButton(
                                        onPressed: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    RecordMissingBody()),
                                          );
                                        },
                                        child: Text(
                                          "عرض قائمة البلاغات",
                                          style: TextStyle(
                                              fontSize: 32,
                                              fontWeight: FontWeight.bold),
                                        )),
                                  ),
                                  // the horizantal ListView is below
                                  // // the horizantal ListView is below
                                  // // the horizantal ListView is below
                                  // // the horizantal ListView is below

                                  //// here is the conent ends
                                  /// here is the conent ends
                                  /// here is the conent ends
                                  /// here is the conent ends
                                  /// here is the conent ends
                                  /// here is the conent ends
                                  /// here is the conent ends
                                  /// here is the conent ends
                                  /// here is the conent ends
                                  ///

                                  // 3

                                  // 4

                                  // 6

                                  // 6
                                  // 9

                                  // the column end below is for the white background column
                                  //  // the column below is the white background column
                                  //  // the column below is the white background column
                                ],
                              ),
                            ),

                            // sliverBox ends here
                          ],
                        ),
                      ),
                    ),
                  ),

                  /// here
                  /// here
                  /// here
                  /// here
                  /// here
                  /// here
                  /// here
                ]),
              ),

////////////////////////////////////////
// the endDrawer is below
///////////////////////////////////////
              endDrawer: Container(
                padding: EdgeInsets.only(top: 7, left: 7, right: 7),
                child: Drawer(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Image.asset("images/title.JPG"),
                      Container(
                        width: widthSize - 35,
                        height: 77,
                        decoration: BoxDecoration(
                            color: Colors.transparent,
                            border: Border.all(
                              color: Colors.transparent,
                              width: 0.7,
                            ),
                            borderRadius: BorderRadius.only(
                              topRight: Radius.circular(73),
                              topLeft: Radius.circular(73),
                              bottomLeft: Radius.circular(73),
                              bottomRight: Radius.circular(73),
                            ) //                 <--- border radius here
                            ),
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => HomePage()),
                            );
                          },
                          hoverColor: Color(0xff047c54),
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 22.0, right: 52, bottom: 22),
                            child: Container(
                              width: widthSize - 35,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  Row(
                                    children: [
                                      Text(" الرئيسية",
                                          style: TextStyle(fontSize: 17)),
                                      SizedBox(width: 12),
                                      Icon(Icons.home_max_outlined),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: widthSize - 35,
                        height: 77,
                        decoration: BoxDecoration(
                            color: Colors.transparent,
                            border: Border.all(
                              color: Colors.transparent,
                              width: 0.7,
                            ),
                            borderRadius: BorderRadius.only(
                              topRight: Radius.circular(73),
                              topLeft: Radius.circular(73),
                              bottomLeft: Radius.circular(73),
                              bottomRight: Radius.circular(73),
                            ) //                 <--- border radius here
                            ),
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      RecordMissing2(notes, varDepartment)),
                            );
                          },
                          hoverColor: Color(0xff047c54),
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 22.0, right: 52, bottom: 22),
                            child: Container(
                              width: widthSize - 35,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  Row(
                                    children: [
                                      Text(" تسجيل المفقودات",
                                          style: TextStyle(fontSize: 17)),
                                      SizedBox(width: 12),
                                      Icon(Icons.person),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      InkWell(
                        hoverColor: Color(0xff047c54),
                        onTap: () {
                          //print(doQueryByName.toString());
                          print("contact us");
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ContactusPage()),
                          );
                        },
                        child: Container(
                          width: widthSize - 35,
                          height: 77,
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 22.0, right: 52, bottom: 22),
                            child: Container(
                              width: widthSize - 35,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  Text(" للتواصل والدعم",
                                      style: TextStyle(fontSize: 17)),
                                  SizedBox(width: 12),
                                  Icon(Icons.person),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),

                      Container(
                        width: widthSize - 35,
                        height: 77,
                        decoration: BoxDecoration(
                            color: Colors.transparent,
                            border: Border.all(
                              color: Colors.transparent,
                              width: 0.7,
                            ),
                            borderRadius: BorderRadius.only(
                              topRight: Radius.circular(73),
                              topLeft: Radius.circular(73),
                              bottomLeft: Radius.circular(73),
                              bottomRight: Radius.circular(73),
                            ) //                 <--- border radius here
                            ),
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => UserPage()),
                            );
                          },
                          hoverColor: Color(0xff047c54),
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 22.0, right: 52, bottom: 22),
                            child: Container(
                              width: widthSize - 35,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  Row(
                                    children: [
                                      Text(" دليل المستخدم",
                                          style: TextStyle(fontSize: 17)),
                                      SizedBox(width: 12),
                                      Icon(Icons.person),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),

                      /// userData is above and it's ending here
                      /// /// userData is above and it's ending here
                      /// /// userData is above and it's ending here
                      Container(
                        width: widthSize - 35,
                        height: 77,
                        decoration: BoxDecoration(
                            color: Colors.transparent,
                            border: Border.all(
                              color: Colors.transparent,
                              width: 0.7,
                            ),
                            borderRadius: BorderRadius.only(
                              topRight: Radius.circular(73),
                              topLeft: Radius.circular(73),
                              bottomLeft: Radius.circular(73),
                              bottomRight: Radius.circular(73),
                            ) //                 <--- border radius here
                            ),
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => Profile()),
                            );
                          },
                          hoverColor: Color(0xff047c54),
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 22.0, right: 52, bottom: 22),
                            child: Container(
                              width: widthSize - 35,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  Row(
                                    children: [
                                      Text(" الأمر السامي",
                                          style: TextStyle(fontSize: 17)),
                                      SizedBox(width: 12),
                                      Icon(Icons.person),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: widthSize - 35,
                        height: 77,
                        decoration: BoxDecoration(
                            color: Colors.transparent,
                            border: Border.all(
                              color: Colors.transparent,
                              width: 0.7,
                            ),
                            borderRadius: BorderRadius.only(
                              topRight: Radius.circular(73),
                              topLeft: Radius.circular(73),
                              bottomLeft: Radius.circular(73),
                              bottomRight: Radius.circular(73),
                            ) //                 <--- border radius here
                            ),
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => Profile()),
                            );
                          },
                          hoverColor: Color(0xff047c54),
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 22.0, right: 52, bottom: 22),
                            child: Container(
                              width: widthSize - 35,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  Row(
                                    children: [
                                      Text(" تسجيل خروج",
                                          style: TextStyle(fontSize: 17)),
                                      SizedBox(width: 12),
                                      Icon(Icons.logout),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              /// the endDrawer ends above
              /// the endDrawer ends above
              /// The end drawer ends above

              // This trailing comma makes auto-formatting nicer for build methods.
            )));
  }

  Future<void> saveTodo(String title) async {
    final todo = ParseObject('Todo')
      ..set('Department', title)
      ..set('Notes', title)
      ..set('Year', '2021');
    await todo.save();
  }

  Future<List<ParseObject>> getTodo() async {
    QueryBuilder<ParseObject> queryTodo =
        QueryBuilder<ParseObject>(ParseObject('Todo'));
    final ParseResponse apiResponse = await queryTodo.query();

    if (apiResponse.success && apiResponse.results != null) {
      return apiResponse.results as List<ParseObject>;
    } else {
      return [];
    }
  }

  Future<void> updateTodo(String id, bool done) async {
    await Future.delayed(Duration(seconds: 1), () {});
  }

  Future<void> deleteTodo(String id) async {
    var todo = ParseObject('Todo')..objectId = id;
    await todo.delete();
  }

  check(varTitle) {
    if (varTitle.toString() == "aa")
      return Text("yummy");
    else
      return Text("yak");
  }
}

/// class _MyHomePageState ends here
