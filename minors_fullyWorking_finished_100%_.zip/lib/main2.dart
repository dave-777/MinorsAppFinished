// ignore_for_file: prefer_const_constructors

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:minors/RecordMissingDetails.dart';
import 'package:minors/Todo.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import 'RecordMissing.dart';
import 'connectToDBCode.dart';
import 'contactus.dart';
import 'exit.dart';
import 'profile.dart';
import 'royalOrder.dart';

import 'userPage.dart';

int numOfRows = 0;
String? varDepartment = "المالية";
String? varDepartment2 = "qa";
String? varDepartment3 = "a";
String? varDepartment4 = "b";
String? varYear = "المالية";
String? varYear2 = "qa";
String? varYear3 = "a";
String? varYear4 = "b";
String? varNotiTypeR = "المالية";
String? varNotiTypeR2 = "qa";
String? varNotiTypeR3 = "a";
String? varNotiTypeR4 = "b";
String? varTransferToDep = "المالية";
String? varTransferToDep2 = "qa";
String? varTransferToDep3 = "a";
String? varTransferToDep4 = "b";
String? varTransferAmount = "المالية";
String? varTransferAmount2 = "qa";
String? varTransferAmount3 = "a";
String? varTransferAmount4 = "b";
String? varTransferNum = "المالية";
String? varTransferNum2 = "qa";
String? varTransferNum3 = "a";
String? varTransferNum4 = "b";
String? notes = "deposited";
int? varOperationNum = 2234;
String? varNotiType;
List<ParseObject> dropdownItems = <ParseObject>[];

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final keyApplicationId = '9XglgwXJxUZdUyIRD0EzrYy7s5bsaRFXlIU7RSzT';
  final keyClientKey = 'DNcLbgsWWNqhCS3VuC9pH4qSInr1xCtLIsSBn39N';
  final keyParseServerUrl = 'https://parseapi.back4app.com';

  await Parse().initialize(keyApplicationId, keyParseServerUrl,
      clientKey: keyClientKey, debug: true);

  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home:
        //RecordMissingBody(),
        HomePage2(),
    //UploadPage(),
  ));
}

class HomePage2 extends StatefulWidget {
  @override
  _HomePage2State createState() => _HomePage2State();
}

class _HomePage2State extends State<HomePage2> {
  // local Vars
  final todoController = TextEditingController();

  String dropdownValue = 'Dog';

  void readData() async {
    var apiResponse = await ParseObject('Missings').getAll();

    if (apiResponse.success) {
      for (var myObject in apiResponse.result) {
        // apiResponse.result
        // for (int i = 0; i < 5; i++) {
        // var myObject;

        debugPrint("Object: " + myObject.get<String>('Department'));
        dropdownItems.add(myObject);
      }
      setState(() {});
    }
  } // readData Method ends here

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    readData();
  }

  void addToDo() async {
    if (todoController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Empty title"),
        duration: Duration(seconds: 2),
      ));
      return;
    }
    await saveTodo(todoController.text);
    setState(() {
      todoController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    double widthSize = MediaQuery.of(context).size.width;
    double heightSize = MediaQuery.of(context).size.height;

    return Scaffold(
      body: Column(
        children: <Widget>[
          Expanded(
            child: FutureBuilder<List<ParseObject>>(
                future: getTodo(),
                builder: (context, snapshot) {
                  switch (snapshot.connectionState) {
                    case ConnectionState.none:
                    case ConnectionState.waiting:
                      return Center(
                        child: Container(
                            width: 100,
                            height: 100,
                            child: CircularProgressIndicator()),
                      );
                    default:
                      if (snapshot.hasError) {
                        return Center(
                          child: Text("Error..."),
                        );
                      }
                      if (!snapshot.hasData) {
                        return Center(
                          child: Text("No Data..."),
                        );
                      } else {
                        return ListView.builder(
                            padding: EdgeInsets.only(top: 10.0),
                            itemCount: snapshot.data!.length,
                            //1,
                            //reverse: true,
                            //snapshot.data!.length,
                            //reverse: true,
                            itemBuilder: (context, index) {
                              //  reverse:
                              //  true;
                              //*************************************
                              //Get Parse Object Values
                              //*************************************
                              //Get Parse Object Values
                              numOfRows = snapshot.data!.length;
                              final varTodo = snapshot.data![index];
                              final varTodo2 = snapshot.data![0];
                              final varTodo3 = snapshot.data![numOfRows - 3];
                              final varTodo4 = snapshot.data![numOfRows - 1];

                              //  final varTitle = varTodo.get<String>('title')!;
                              //  final varDone = varTodo.get<bool>('done')!;
                              final notes = varTodo.get<String>('Notes')!;
                              var varDepartment =
                                  varTodo.get<String>('Department')!;
                              varDepartment2 =
                                  varTodo2.get<String>('Department')!;
                              varDepartment3 =
                                  varTodo3.get<String>('Department')!;
                              varDepartment4 =
                                  varTodo4.get<String>('Department')!;
                              //////////////////////////////
                              varYear = varTodo.get<String>('Year')!;
                              varYear2 = varTodo2.get<String>('Year')!;
                              varYear3 = varTodo3.get<String>('Year')!;
                              varYear4 = varTodo4.get<String>('Year')!;

                              varNotiTypeR = varTodo.get<String>('NotiType')!;
                              varNotiTypeR2 = varTodo2.get<String>('NotiType')!;
                              varNotiTypeR3 = varTodo3.get<String>('NotiType')!;
                              varNotiTypeR4 = varTodo4.get<String>('NotiType')!;

                              varTransferNum =
                                  varTodo.get<String>('TransferNumber')!;
                              varTransferNum2 =
                                  varTodo2.get<String>('TransferNumber')!;

                              varTransferNum3 =
                                  varTodo3.get<String>('TransferNumber')!;
                              varTransferNum4 =
                                  varTodo4.get<String>('TransferNumber')!;

                              varTransferAmount =
                                  varTodo.get<String>('TransferAmount')!;
                              varTransferAmount2 =
                                  varTodo2.get<String>('TransferAmount')!;

                              varTransferAmount3 =
                                  varTodo3.get<String>('TransferAmount')!;
                              varTransferAmount4 =
                                  varTodo4.get<String>('TransferAmount')!;

                              varTransferToDep = varTodo
                                  .get<String>('TranferToDepartmentName')!;
                              varTransferToDep2 = varTodo2
                                  .get<String>('TranferToDepartmentName')!;

                              varTransferToDep3 = varTodo3
                                  .get<String>('TranferToDepartmentName')!;
                              varTransferToDep4 = varTodo4
                                  .get<String>('TranferToDepartmentName')!;

                              //*************************************    //*************************************

                              return RecordMissingBody();
                            });
                      }
                  }
                }),
          ),

          // sliverBox ends here
        ],
      ),
    );
  }

  Future<void> saveTodo(String title) async {
    final todo = ParseObject('Todo')
      ..set('title', title)
      ..set('done', false);
    await todo.save();
  }

  Future<List<ParseObject>> getTodo() async {
    QueryBuilder<ParseObject> queryTodo =
        QueryBuilder<ParseObject>(ParseObject('Missings'));
    final ParseResponse apiResponse = await queryTodo.query();

    if (apiResponse.success && apiResponse.results != null) {
      return apiResponse.results as List<ParseObject>;
    } else {
      return [];
    }
  }

  Future<void> updateTodo(String id, bool done) async {
    await Future.delayed(Duration(seconds: 1), () {});
  }

  Future<void> deleteTodo(String id) async {
    var todo = ParseObject('Todo')..objectId = id;
    await todo.delete();
  }

  check(varTitle) {
    if (varTitle.toString() == "aa")
      return Text("yummy");
    else
      return Text("yak");
  }
} // Class _Todo ends here
// choose file
