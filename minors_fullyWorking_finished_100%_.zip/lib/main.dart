// ignore_for_file: prefer_const_constructors

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:minors/RecordMissingDetails.dart';
import 'package:minors/Todo.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import 'RecordMissing.dart';
import 'connectToDBCode.dart';
import 'contactus.dart';
import 'exit.dart';
import 'profile.dart';
import 'royalOrder.dart';

import 'userPage.dart';

int numOfRows = 0;
String? varDepartment = "المالية";
String? varDepartment2 = "qa";
String? varDepartment3 = "a";
String? varDepartment4 = "b";
String? varYear = "المالية";
String? varYear2 = "qa";
String? varYear3 = "a";
String? varYear4 = "b";
String? varNotiTypeR = "المالية";
String? varNotiTypeR2 = "qa";
String? varNotiTypeR3 = "a";
String? varNotiTypeR4 = "b";
String? varTransferToDep = "المالية";
String? varTransferToDep2 = "qa";
String? varTransferToDep3 = "a";
String? varTransferToDep4 = "b";
String? varTransferAmount = "المالية";
String? varTransferAmount2 = "qa";
String? varTransferAmount3 = "a";
String? varTransferAmount4 = "b";
String? varTransferNum = "المالية";
String? varTransferNum2 = "qa";
String? varTransferNum3 = "a";
String? varTransferNum4 = "b";
String? notes = "deposited";
int? varOperationNum = 2234;
String? varNotiType;
List<ParseObject> dropdownItems = <ParseObject>[];

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final keyApplicationId = '9XglgwXJxUZdUyIRD0EzrYy7s5bsaRFXlIU7RSzT';
  final keyClientKey = 'DNcLbgsWWNqhCS3VuC9pH4qSInr1xCtLIsSBn39N';
  final keyParseServerUrl = 'https://parseapi.back4app.com';

  await Parse().initialize(keyApplicationId, keyParseServerUrl,
      clientKey: keyClientKey, debug: true);

  if (canGo == true) {
    Future.delayed(Duration(milliseconds: 700), () {
      // Do something

      print("kkkkkkkkkk");
    });
  }
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home:
        //RecordMissingBody(),
        HomePage(),
    //UploadPage(),
  ));
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // local Vars
  final todoController = TextEditingController();

  String? dropdownValue = 'Dog';

  void readData() async {
    var apiResponse = await ParseObject('Missings').getAll();

    if (apiResponse.success) {
      for (var myObject in apiResponse.result) {
        // apiResponse.result
        // for (int i = 0; i < 5; i++) {
        // var myObject;

        debugPrint("Object: " + myObject.get<String>('Department'));
        dropdownItems.add(myObject);
      }
      setState(() {});
    }

    if (canGo == true) {
      
      setState(() {
        Future.delayed(Duration(milliseconds: 100), () {
          // Do something
          canGo = false;

          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => Todo()),
          );
        });
      });
    }
  } // readData Method ends here

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    readData();
  }

  void addToDo() async {
    if (todoController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Empty title"),
        duration: Duration(seconds: 2),
      ));
      return;
    }
    await saveTodo(todoController.text);
    setState(() {
      todoController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    double widthSize = MediaQuery.of(context).size.width;
    double heightSize = MediaQuery.of(context).size.height;

    return RefreshIndicator(
      onRefresh: () async {
        HomePage();
      },
      child: Scaffold(
        body: Column(
          children: <Widget>[
            Expanded(
              child: FutureBuilder<List<ParseObject>>(
                  future: getTodo(),
                  builder: (context, snapshot) {
                    switch (snapshot.connectionState) {
                      case ConnectionState.none:
                      case ConnectionState.waiting:
                        return Center(
                          child: Container(
                              width: 100,
                              height: 100,
                              child: CircularProgressIndicator()),
                        );
                      default:
                        if (snapshot.hasError) {
                          return Center(
                            child: Text("Error..."),
                          );
                        }
                        if (!snapshot.hasData) {
                          return Center(
                            child: Text("No Data..."),
                          );
                        } else {
                          return ListView.builder(
                              padding: EdgeInsets.only(top: 10.0),
                              itemCount:
                                  //snapshot.data!.length,
                                  1,
                              //reverse: true,
                              //snapshot.data!.length,
                              //reverse: true,
                              itemBuilder: (context, index) {
                                //  reverse:
                                //  true;
                                //*************************************
                                //Get Parse Object Values
                                //*************************************
                                //Get Parse Object Values
                                numOfRows = snapshot.data!.length;
                                final varTodo = snapshot.data![index];
                                final varTodo2 = snapshot.data![0];
                                final varTodo3 = snapshot.data![numOfRows - 3];
                                final varTodo4 = snapshot.data![numOfRows - 1];

                                //  final varTitle = varTodo.get<String>('title')!;
                                //  final varDone = varTodo.get<bool>('done')!;
                                final notes = varTodo.get<String>('Notes')!;
                                var varDepartment =
                                    varTodo.get<String>('Department')!;
                                varDepartment2 =
                                    varTodo2.get<String>('Department')!;
                                varDepartment3 =
                                    varTodo3.get<String>('Department')!;
                                varDepartment4 =
                                    varTodo4.get<String>('Department')!;
                                //////////////////////////////
                                varYear = varTodo.get<String>('Year')!;
                                varYear2 = varTodo2.get<String>('Year')!;
                                varYear3 = varTodo3.get<String>('Year')!;
                                varYear4 = varTodo4.get<String>('Year')!;

                                varNotiTypeR = varTodo.get<String>('NotiType')!;
                                varNotiTypeR2 =
                                    varTodo2.get<String>('NotiType')!;
                                varNotiTypeR3 =
                                    varTodo3.get<String>('NotiType')!;
                                varNotiTypeR4 =
                                    varTodo4.get<String>('NotiType')!;

                                varTransferNum =
                                    varTodo.get<String>('TransferNumber')!;
                                varTransferNum2 =
                                    varTodo2.get<String>('TransferNumber')!;

                                varTransferNum3 =
                                    varTodo3.get<String>('TransferNumber')!;
                                varTransferNum4 =
                                    varTodo4.get<String>('TransferNumber')!;

                                varTransferAmount =
                                    varTodo.get<String>('TransferAmount')!;
                                varTransferAmount2 =
                                    varTodo2.get<String>('TransferAmount')!;

                                varTransferAmount3 =
                                    varTodo3.get<String>('TransferAmount')!;
                                varTransferAmount4 =
                                    varTodo4.get<String>('TransferAmount')!;

                                varTransferToDep = varTodo
                                    .get<String>('TranferToDepartmentName')!;
                                varTransferToDep2 = varTodo2
                                    .get<String>('TranferToDepartmentName')!;

                                varTransferToDep3 = varTodo3
                                    .get<String>('TranferToDepartmentName')!;
                                varTransferToDep4 = varTodo4
                                    .get<String>('TranferToDepartmentName')!;

                                //*************************************    //*************************************

                                return Container(
                                  height: 1122,
                                  child: Scaffold(
                                    backgroundColor: Color(0xf2f6f4f4),
                                    body: Padding(
                                      padding: const EdgeInsets.all(12),
                                      child: CustomScrollView(
                                        slivers: [
                                          SliverAppBar(
                                            pinned: true,
                                            floating: true,
                                            foregroundColor: Color(0xff000000),
                                            backgroundColor: Color(0xffffffff),
                                            //Color(0xffb4b0b3),
                                            leadingWidth: 72,
                                            title: Center(
                                                // text below is الصفحة الرئيسية title
                                                child: Text(
                                              "  الصفحة الرئيسية ",
                                              style: TextStyle(
                                                  color: Color(0xff000000),
                                                  fontSize: 22),
                                            )),
                                            leading: Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 0.8),
                                              child: IconButton(
                                                icon: Icon(
                                                  Icons.person,
                                                  color: Color(0xff000000),
                                                  size: 30.0,
                                                ),
                                                onPressed: () {
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            Profile()),
                                                  );
                                                },
                                              ),
                                            ),
                                          ),
                                          SliverToBoxAdapter(
                                            child: SingleChildScrollView(
                                              child: Container(
                                                width: widthSize,
                                                child: Column(
                                                  // fit: StackFit.passthrough,
                                                  //alignment: Alignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    // Icon(Icons.bar_chart_rounded),
                                                    //
                                                    /*
                                                    DropdownButton<String>(
                                                        items: dropdownItems.map(
                                                            (ParseObject value) {
                                                          return DropdownMenuItem<
                                                              String>(
                                                            value:
                                                                value.get<String>(
                                                                    'Department'),
                                                            child: Text(value.get<
                                                                    String>(
                                                                'Department')!),
                                                          );
                                                        }).toList(),
                                                        onChanged: (_) {}),
                                                        */

                                                    Container(
                                                      // height: 77,
                                                      padding: EdgeInsets.only(
                                                          top: 25.2,
                                                          left: 0,
                                                          right: 10),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: <Widget>[
                                                          Stack(
                                                            children: [
                                                              Container(
                                                                  width:
                                                                      widthSize -
                                                                          37,
                                                                  height: 82,
                                                                  padding: EdgeInsets
                                                                      .only(
                                                                          top:
                                                                              10),
                                                                  margin: EdgeInsets
                                                                      .only(
                                                                          top:
                                                                              50),
                                                                  decoration: BoxDecoration(
                                                                      color: Colors.white,
                                                                      border: Border.all(
                                                                        color: Colors
                                                                            .green,
                                                                        width:
                                                                            0.7,
                                                                      ),
                                                                      borderRadius: BorderRadius.only(
                                                                        topRight:
                                                                            Radius.circular(13),
                                                                        topLeft:
                                                                            Radius.circular(13),
                                                                      ) //                 <--- border radius here
                                                                      ),

                                                                  //width: widthSize,
                                                                  child: Padding(
                                                                    padding:
                                                                        const EdgeInsets.all(
                                                                            8.0),
                                                                    child:
                                                                        Column(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                            "عدد بلاغات المفقودا ت      "),
                                                                        Text(
                                                                            numOfRows
                                                                                .toString(),
/*
                                                                            snapshot
                                                                                .data!
                                                                                .length
                                                                                .toString(),
*/
                                                                            // numOfRows
                                                                            //    .toString(),
                                                                            style:
                                                                                TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                                                                      ],
                                                                    ),
                                                                  )),
                                                              Positioned(
                                                                // right: 77,
                                                                bottom: 52,
                                                                left:
                                                                    widthSize /
                                                                        1.7,
                                                                //  width: 77,
                                                                // height: 77,
                                                                child:
                                                                    Container(
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    //color: Color(0xff000000),
                                                                    gradient:
                                                                        LinearGradient(
                                                                      begin: Alignment
                                                                          .topRight,
                                                                      end: Alignment
                                                                          .bottomLeft,
                                                                      colors: [
                                                                        Color(
                                                                            0xff10240b),
                                                                        Color(
                                                                            0xff000000),
                                                                      ],
                                                                    ),
                                                                    border:
                                                                        Border
                                                                            .all(
                                                                      color: Colors
                                                                          .red,
                                                                      width:
                                                                          0.7,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .only(
                                                                      topRight:
                                                                          Radius.circular(
                                                                              27),
                                                                      topLeft: Radius
                                                                          .circular(
                                                                              27),
                                                                      bottomLeft:
                                                                          Radius.circular(
                                                                              27),
                                                                      bottomRight:
                                                                          Radius.circular(
                                                                              27),
                                                                    ),
                                                                    boxShadow: [
                                                                      BoxShadow(
                                                                          color: Colors
                                                                              .grey
                                                                              .shade600,
                                                                          spreadRadius:
                                                                              1,
                                                                          blurRadius:
                                                                              15)
                                                                    ], //                 <--- border radius here
                                                                  ),
                                                                  // color: Color(0xffa48482),
                                                                  child: Container(
                                                                      width: 77,
                                                                      height: 77,
                                                                      child: Icon(
                                                                        Icons
                                                                            .bar_chart,
                                                                        size:
                                                                            37,
                                                                        color: Colors
                                                                            .white,
                                                                      )),

                                                                  //Image.asset("images/ana.JPG")),
                                                                  //Icon(Icons.analytics,
                                                                  //  size: 75, color: Colors.white),
                                                                ),
                                                              ),
                                                            ], // Stack Children ends here
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    // above is the end of the first image row container
                                                    // above is the end of the first image row container
                                                    //

                                                    // above is the end of the first image row container
                                                    // above is the end of the first image row container

                                                    Container(
                                                      // height: 77,
                                                      padding: EdgeInsets.only(
                                                          top: 25.2,
                                                          left: 0,
                                                          right: 10),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          Stack(
                                                            children: [
                                                              Container(
                                                                  width:
                                                                      widthSize -
                                                                          37,
                                                                  height: 82,
                                                                  padding: EdgeInsets
                                                                      .only(
                                                                          top:
                                                                              10),
                                                                  margin: EdgeInsets
                                                                      .only(
                                                                          top:
                                                                              50),
                                                                  decoration: BoxDecoration(
                                                                      color: Colors.white,
                                                                      border: Border.all(
                                                                        color: Colors
                                                                            .green,
                                                                        width:
                                                                            0.7,
                                                                      ),
                                                                      borderRadius: BorderRadius.only(
                                                                        topRight:
                                                                            Radius.circular(13),
                                                                        topLeft:
                                                                            Radius.circular(13),
                                                                      ) //                 <--- border radius here
                                                                      ),

                                                                  //width: widthSize,
                                                                  child: Padding(
                                                                    padding:
                                                                        const EdgeInsets.all(
                                                                            8.0),
                                                                    child:
                                                                        Column(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                            "اجمالي الحوالات"),
                                                                        Text(
                                                                            "ر.س 0",
                                                                            style:
                                                                                TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                                                                      ],
                                                                    ),
                                                                  )),
                                                              Positioned(
                                                                // right: 77,
                                                                bottom: 52,
                                                                left:
                                                                    widthSize /
                                                                        1.7,

                                                                //227,
                                                                //  width: 77,
                                                                // height: 77,
                                                                child:
                                                                    Container(
                                                                  decoration:
                                                                      BoxDecoration(
                                                                          gradient:
                                                                              LinearGradient(
                                                                            begin:
                                                                                Alignment.topRight,
                                                                            end:
                                                                                Alignment.bottomLeft,
                                                                            colors: [
                                                                              Color(0xff047e45),
                                                                              Color(0xff0ab271),
                                                                            ],
                                                                          ),
                                                                          //color: Color(0xff04863e),

                                                                          border: Border.all(
                                                                            color:
                                                                                Colors.green,
                                                                            width:
                                                                                0.7,
                                                                          ),
                                                                          borderRadius: BorderRadius.only(
                                                                            topRight:
                                                                                Radius.circular(27),
                                                                            topLeft:
                                                                                Radius.circular(27),
                                                                            bottomLeft:
                                                                                Radius.circular(27),
                                                                            bottomRight:
                                                                                Radius.circular(27),
                                                                          ),
                                                                          boxShadow: [
                                                                        BoxShadow(
                                                                            color: Colors
                                                                                .grey.shade600,
                                                                            spreadRadius:
                                                                                1,
                                                                            blurRadius:
                                                                                15)
                                                                      ] //                 <--- border radius here
                                                                          ),
                                                                  // color: Color(0xffa48482),
                                                                  child: Container(
                                                                      width: 77,
                                                                      height: 77,
                                                                      child: Icon(
                                                                        Icons
                                                                            .bar_chart,
                                                                        size:
                                                                            37,
                                                                        color: Colors
                                                                            .white,
                                                                      )),
                                                                  //   Image.asset("images/greenAna.JPG")),
                                                                  //Icon(Icons.analytics,
                                                                  //  size: 75, color: Colors.white),
                                                                ),
                                                              ),
                                                            ], // Stack Children ends here
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    // above is the end of the 2nd image row container
                                                    // above is the end of the 2nd image row container
                                                    //

                                                    Container(
                                                      // height: 77,
                                                      padding: EdgeInsets.only(
                                                          top: 25.2,
                                                          left: 0,
                                                          right: 10),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          Stack(
                                                            children: [
                                                              Container(
                                                                  width:
                                                                      widthSize -
                                                                          37,
                                                                  height: 82,
                                                                  padding: EdgeInsets
                                                                      .only(
                                                                          top:
                                                                              10),
                                                                  margin: EdgeInsets
                                                                      .only(
                                                                          top:
                                                                              50),
                                                                  decoration: BoxDecoration(
                                                                      color: Colors.white,
                                                                      border: Border.all(
                                                                        color: Colors
                                                                            .green,
                                                                        width:
                                                                            0.7,
                                                                      ),
                                                                      borderRadius: BorderRadius.only(
                                                                        topRight:
                                                                            Radius.circular(13),
                                                                        topLeft:
                                                                            Radius.circular(13),
                                                                      ) //                 <--- border radius here
                                                                      ),

                                                                  //width: widthSize,
                                                                  child: Padding(
                                                                    padding:
                                                                        const EdgeInsets.all(
                                                                            8.0),
                                                                    child:
                                                                        Column(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                            "عدد المفقودات النقدية"),
                                                                        Text(
                                                                            "0",
                                                                            style:
                                                                                TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                                                                      ],
                                                                    ),
                                                                  )),
                                                              Positioned(
                                                                // right: 77,
                                                                bottom: 52,
                                                                left:
                                                                    widthSize /
                                                                        1.7,
                                                                //  width: 77,
                                                                // height: 77,
                                                                child:
                                                                    Container(
                                                                  decoration:
                                                                      BoxDecoration(
                                                                          gradient:
                                                                              LinearGradient(
                                                                            begin:
                                                                                Alignment.topRight,
                                                                            end:
                                                                                Alignment.bottomLeft,
                                                                            colors: [
                                                                              Color(0xff09ae1f),
                                                                              Color(0xff079d1b),
                                                                            ],
                                                                          ),
                                                                          //color: Color(0xff3fa804),
                                                                          border: Border.all(
                                                                            color:
                                                                                Colors.grey,
                                                                            width:
                                                                                0.7,
                                                                          ),
                                                                          borderRadius: BorderRadius.only(
                                                                            topRight:
                                                                                Radius.circular(27),
                                                                            topLeft:
                                                                                Radius.circular(27),
                                                                            bottomLeft:
                                                                                Radius.circular(27),
                                                                            bottomRight:
                                                                                Radius.circular(27),
                                                                          ),
                                                                          boxShadow: [
                                                                        BoxShadow(
                                                                            color: Colors
                                                                                .grey.shade600,
                                                                            spreadRadius:
                                                                                1,
                                                                            blurRadius:
                                                                                15)
                                                                      ] //                 <--- border radius here
                                                                          ),
                                                                  // color: Color(0xffa48482),
                                                                  child: Container(
                                                                      width: 77,
                                                                      height: 77,
                                                                      child: Icon(
                                                                        Icons
                                                                            .bar_chart,
                                                                        size:
                                                                            37,
                                                                        color: Colors
                                                                            .white,
                                                                      )),
                                                                  //Image.asset(
                                                                  // "images/LightGreenAna.JPG")),
                                                                  //Icon(Icons.analytics,
                                                                  //  size: 75, color: Colors.white),
                                                                ),
                                                              ),
                                                            ], // Stack Children ends here
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    // above is the end of the green image row container
                                                    // above is the end of the greeen image row container

                                                    Container(
                                                      // height: 77,
                                                      padding: EdgeInsets.only(
                                                          top: 25.2,
                                                          left: 0,
                                                          right: 10),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          Stack(
                                                            children: [
                                                              Container(
                                                                  width:
                                                                      widthSize -
                                                                          37,
                                                                  height: 82,
                                                                  padding: EdgeInsets
                                                                      .only(
                                                                          top:
                                                                              10),
                                                                  margin: EdgeInsets
                                                                      .only(
                                                                          top:
                                                                              50),
                                                                  decoration: BoxDecoration(
                                                                      color: Colors.white,
                                                                      border: Border.all(
                                                                        color: Colors
                                                                            .green,
                                                                        width:
                                                                            0.7,
                                                                      ),
                                                                      borderRadius: BorderRadius.only(
                                                                        topRight:
                                                                            Radius.circular(13),
                                                                        topLeft:
                                                                            Radius.circular(13),
                                                                      ) //                 <--- border radius here
                                                                      ),

                                                                  //width: widthSize,
                                                                  child: Padding(
                                                                    padding:
                                                                        const EdgeInsets.all(
                                                                            8.0),
                                                                    child:
                                                                        Column(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                          "عدد المفقودات العينية",
                                                                        ),
                                                                        Text(
                                                                            "0",
                                                                            style:
                                                                                TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                                                                      ],
                                                                    ),
                                                                  )),
                                                              Positioned(
                                                                // right: 77,
                                                                bottom: 52,
                                                                left:
                                                                    widthSize /
                                                                        1.7,
                                                                //  width: 77,
                                                                // height: 77,
                                                                child:
                                                                    Container(
                                                                  decoration:
                                                                      BoxDecoration(
                                                                          //color: Color(0xff0583be),

                                                                          gradient:
                                                                              LinearGradient(
                                                                            begin:
                                                                                Alignment.topRight,
                                                                            end:
                                                                                Alignment.bottomLeft,
                                                                            colors: [
                                                                              Color(0xff82ccef),
                                                                              Color(0xff0b2c9a),
                                                                            ],
                                                                          ),
                                                                          border: Border.all(
                                                                            color:
                                                                                Color(0xffbff0fe),
                                                                            width:
                                                                                0.7,
                                                                          ),
                                                                          borderRadius: BorderRadius.only(
                                                                            topRight:
                                                                                Radius.circular(27),
                                                                            topLeft:
                                                                                Radius.circular(27),
                                                                            bottomLeft:
                                                                                Radius.circular(27),
                                                                            bottomRight:
                                                                                Radius.circular(27),
                                                                          ),
                                                                          boxShadow: [
                                                                        BoxShadow(
                                                                            color: Colors
                                                                                .grey.shade600,
                                                                            spreadRadius:
                                                                                1,
                                                                            blurRadius:
                                                                                15)
                                                                      ] //                 <--- border radius here
                                                                          ),
                                                                  // color: Color(0xffa48482),
                                                                  child: Container(
                                                                      width: 77,
                                                                      height: 77,
                                                                      child: Icon(
                                                                        Icons
                                                                            .bar_chart,
                                                                        size:
                                                                            37,
                                                                        color: Colors
                                                                            .white,
                                                                      )),

                                                                  // Image.asset("images/blueAna.JPG")),
                                                                  //Icon(Icons.analytics,
                                                                  //  size: 75, color: Colors.white),
                                                                ),
                                                              ),
                                                            ], // Stack Children ends here
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    // above is the end of the last image row container
                                                    // above is the end of the last image row container
                                                    //
                                                    //

                                                    Container(
                                                      margin: EdgeInsets.only(
                                                          top: 22),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceEvenly,
                                                        children: <Widget>[
                                                          Column(
                                                            children: [
                                                              Container(
                                                                width: 138,
                                                                decoration:
                                                                    BoxDecoration(
                                                                        color: Colors
                                                                            .white,
                                                                        border: Border
                                                                            .all(
                                                                          color:
                                                                              Colors.grey,
                                                                          width:
                                                                              0.7,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.only(
                                                                          topRight:
                                                                              Radius.circular(13),
                                                                          topLeft:
                                                                              Radius.circular(13),
                                                                          bottomLeft:
                                                                              Radius.circular(13),
                                                                          bottomRight:
                                                                              Radius.circular(13),
                                                                        ) //                 <--- border radius here
                                                                        ),
                                                                //  width: widthSize / 3 + 30,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        right:
                                                                            10),
                                                                //  color: Colors.white,
                                                                child: Stack(
                                                                    children: [
                                                                      Container(
                                                                        decoration: BoxDecoration(
                                                                            color: Colors.red,
                                                                            border: Border.all(
                                                                              color: Colors.white,
                                                                              width: 0,
                                                                            ),
                                                                            borderRadius: BorderRadius.only(
                                                                              topRight: Radius.circular(13),
                                                                              topLeft: Radius.circular(13),
                                                                              bottomLeft: Radius.circular(13),
                                                                              bottomRight: Radius.circular(13),
                                                                            ) //                 <--- border radius here
                                                                            ),
                                                                        margin: EdgeInsets.only(
                                                                            top:
                                                                                22,
                                                                            left:
                                                                                17,
                                                                            right:
                                                                                17),
                                                                        // color: Colors.red,
                                                                        child:
                                                                            Column(
                                                                          children: [
                                                                            Container(
                                                                              width: 200,
                                                                              margin: EdgeInsets.only(top: 22),
                                                                              padding: EdgeInsets.only(top: 22, left: 7, right: 8, bottom: 7),
                                                                              color: Colors.red,
                                                                              child: Text("0.8 _ _ _ _ _ _", style: TextStyle(color: Color(0xffcdcdcd))),
                                                                            ),
                                                                            Container(
                                                                              margin: EdgeInsets.only(top: 22),
                                                                              padding: EdgeInsets.only(top: 22, left: 7, right: 8, bottom: 7),
                                                                              color: Colors.red,
                                                                              child: Text("0.4 _ _ _ _ _ _", style: TextStyle(color: Color(0xffcdcdcd))),
                                                                            ),
                                                                            Container(
                                                                              margin: EdgeInsets.only(top: 22),
                                                                              padding: EdgeInsets.only(top: 22, left: 7, right: 8, bottom: 7),
                                                                              color: Colors.red,
                                                                              child: Text("0 _ _ _ _ _ _ _ _", style: TextStyle(color: Color(0xffcdcdcd))),
                                                                            ),
                                                                            // Text("التحويلات النفدية")
                                                                            //
                                                                            Container(
                                                                              width: widthSize / 3 + 30,
                                                                              color: Colors.white,
                                                                              child: Column(
                                                                                children: [
                                                                                  Text("  التحويلات  النقدية"),
                                                                                  Container(
                                                                                    child: Text("________________", style: TextStyle(color: Colors.black)),
                                                                                  ),
                                                                                  Container(
                                                                                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                                                                      Text("تم تحديثه للتو"),
                                                                                      Icon(Icons.update_sharp),
                                                                                    ]),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ]),
                                                              ),
                                                            ],
                                                          ),
                                                          SizedBox(width: 2),
                                                          Column(
                                                            children: [
                                                              Container(
                                                                //width: 200,
                                                                width: 138,

                                                                decoration:
                                                                    BoxDecoration(
                                                                        color: Colors
                                                                            .white,
                                                                        border: Border
                                                                            .all(
                                                                          color:
                                                                              Colors.grey,
                                                                          width:
                                                                              0.7,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.only(
                                                                          topRight:
                                                                              Radius.circular(13),
                                                                          topLeft:
                                                                              Radius.circular(13),
                                                                          //  bottomLeft: Radius.circular(13),
                                                                          //  bottomRight: Radius.circular(13),
                                                                        ) //                 <--- border radius here
                                                                        ),
                                                                // width: widthSize / 3 + 30,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        right:
                                                                            0,
                                                                        left:
                                                                            0),
                                                                //   color: Colors.white,
                                                                child: Stack(
                                                                    children: [
                                                                      Container(
                                                                        // alignment: Alignment.center,
                                                                        // margin: EdgeInsets.only(right: 35, left: 35),
                                                                        //
                                                                        decoration: BoxDecoration(
                                                                            // color: Colors.red,
                                                                            color: Color(0xff078176),
                                                                            border: Border.all(
                                                                              color: Colors.white,
                                                                              width: 0,
                                                                            ),
                                                                            borderRadius: BorderRadius.only(
                                                                              topRight: Radius.circular(13),
                                                                              topLeft: Radius.circular(13),
                                                                              bottomLeft: Radius.circular(13),
                                                                              bottomRight: Radius.circular(13),
                                                                            ) //                 <--- border radius here
                                                                            ),

                                                                        margin: EdgeInsets.only(
                                                                            top:
                                                                                22,
                                                                            right:
                                                                                15,
                                                                            left:
                                                                                15),
                                                                        // color: Color(0xff078176),
                                                                        //Colors.greenAccent,
                                                                        child:
                                                                            Column(
                                                                          children: [
                                                                            Container(
                                                                              //width: 200,
                                                                              margin: EdgeInsets.only(top: 22),
                                                                              padding: EdgeInsets.only(top: 22, left: 7, right: 8, bottom: 7),
                                                                              color: Color(0xff078176),
                                                                              child: Text("0.7 _ _ _ _ _ _ _", style: TextStyle(color: Color(0xffcdcdcd))),
                                                                            ),
                                                                            Container(
                                                                              margin: EdgeInsets.only(top: 22),
                                                                              padding: EdgeInsets.only(top: 22, left: 7, right: 8, bottom: 7),
                                                                              color: Colors.transparent,
                                                                              child: Text("0.4 _ _ _ _ _ _ _", style: TextStyle(color: Color(0xffcdcdcd))),
                                                                            ),
                                                                            Container(
                                                                              margin: EdgeInsets.only(top: 22),
                                                                              padding: EdgeInsets.only(top: 22, left: 7, right: 8, bottom: 7),
                                                                              color: Colors.transparent,
                                                                              child: Text("0 _ _ _ _ _ _ _ _", style: TextStyle(color: Color(0xffcdcdcd))),
                                                                            ),
                                                                            // Text("التحويلات النفدية")
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ]),
                                                              ),
                                                              Container(
                                                                width: 138,

                                                                decoration:
                                                                    BoxDecoration(
                                                                        color: Colors
                                                                            .white,
                                                                        border: Border
                                                                            .all(
                                                                          color:
                                                                              Colors.white,
                                                                          width:
                                                                              0.7,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.only(
                                                                          //   topRight: Radius.circular(13),
                                                                          //  topLeft: Radius.circular(13),
                                                                          bottomLeft:
                                                                              Radius.circular(13),
                                                                          bottomRight:
                                                                              Radius.circular(13),
                                                                        ) //                 <--- border radius here
                                                                        ),
                                                                // width: widthSize / 3 + 30,
                                                                //color: Colors.white,
                                                                child: Column(
                                                                  children: [
                                                                    Text(
                                                                        "المفقود حسب السنة"),
                                                                    Container(
                                                                      child: Text(
                                                                          "________________"),
                                                                    ),
                                                                    Container(
                                                                      child: Row(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.center,
                                                                          children: [
                                                                            Text("تم تحديثه للتو"),
                                                                            Icon(Icons.update_sharp),
                                                                          ]),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),

                                                    Container(
                                                      margin: EdgeInsets.only(
                                                          top: 27),
                                                      alignment:
                                                          Alignment.center,
                                                      child: Text(
                                                          "  الهيئة العامة للولاية على أموال القاصرين ومن في حكمهم @"),
                                                    ),

                                                    Container(
                                                      margin: EdgeInsets.only(
                                                          top: 2),
                                                      alignment:
                                                          Alignment.center,
                                                      child: Text("  2022"),
                                                    ),
                                                    // the parent column ends below
                                                    // the parent column ends below
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          // sliverBox ends here
                                        ],
                                      ),
                                    ),

////////////////////////////////////////
// the endDrawer is below
///////////////////////////////////////
                                    endDrawer: Container(
                                      color: Color(0xffffffff),
                                      padding: EdgeInsets.only(
                                          top: 7, left: 7, right: 7),
                                      child: Drawer(
                                        child: Container(
                                          color: Colors.transparent,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Image.asset("images/title.JPG"),
                                              Container(
                                                width: widthSize - 35,
                                                height: 77,
                                                decoration: BoxDecoration(
                                                    color: Colors.transparent,
                                                    border: Border.all(
                                                      color: Colors.transparent,
                                                      width: 0.7,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topRight:
                                                          Radius.circular(73),
                                                      topLeft:
                                                          Radius.circular(73),
                                                      bottomLeft:
                                                          Radius.circular(73),
                                                      bottomRight:
                                                          Radius.circular(73),
                                                    ) //                 <--- border radius here
                                                    ),
                                                child: InkWell(
                                                  onTap: () {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              HomePage()),
                                                    );
                                                  },
                                                  hoverColor: Color(0xff047c54),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 22.0,
                                                            right: 52,
                                                            bottom: 22),
                                                    child: Container(
                                                      width: widthSize - 35,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: <Widget>[
                                                          Row(
                                                            children: [
                                                              Text(" الرئيسية",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          17)),
                                                              SizedBox(
                                                                  width: 12),
                                                              Icon(Icons
                                                                  .home_max_outlined),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),

                                              Container(
                                                width: widthSize - 35,
                                                height: 77,
                                                decoration: BoxDecoration(
                                                    color: Colors.transparent,
                                                    border: Border.all(
                                                      color: Colors.transparent,
                                                      width: 0.7,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topRight:
                                                          Radius.circular(73),
                                                      topLeft:
                                                          Radius.circular(73),
                                                      bottomLeft:
                                                          Radius.circular(73),
                                                      bottomRight:
                                                          Radius.circular(73),
                                                    ) //                 <--- border radius here
                                                    ),
                                                child: InkWell(
                                                  onTap: () {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              RecordMissingDetails()),
                                                    );
                                                  },
                                                  hoverColor: Color(0xff047c54),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 22.0,
                                                            right: 52,
                                                            bottom: 22),
                                                    child: Container(
                                                      width: widthSize - 35,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: <Widget>[
                                                          Row(
                                                            children: [
                                                              Text(
                                                                  " مشاهدة بلاغات المفقودات",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          17)),
                                                              SizedBox(
                                                                  width: 12),
                                                              Icon(
                                                                  Icons.person),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),

                                              Container(
                                                width: widthSize - 35,
                                                height: 77,
                                                decoration: BoxDecoration(
                                                    color: Colors.transparent,
                                                    border: Border.all(
                                                      color: Colors.transparent,
                                                      width: 0.7,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topRight:
                                                          Radius.circular(73),
                                                      topLeft:
                                                          Radius.circular(73),
                                                      bottomLeft:
                                                          Radius.circular(73),
                                                      bottomRight:
                                                          Radius.circular(73),
                                                    ) //                 <--- border radius here
                                                    ),
                                                child: InkWell(
                                                  onTap: () {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              Todo()),
                                                    );
                                                  },
                                                  hoverColor: Color(0xff047c54),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 22.0,
                                                            right: 52,
                                                            bottom: 22),
                                                    child: Container(
                                                      width: widthSize - 35,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: <Widget>[
                                                          Row(
                                                            children: [
                                                              Text(
                                                                  " تسجيل بلاغ",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          17)),
                                                              SizedBox(
                                                                  width: 12),
                                                              Icon(
                                                                  Icons.person),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: widthSize - 35,
                                                height: 77,
                                                decoration: BoxDecoration(
                                                    color: Colors.transparent,
                                                    border: Border.all(
                                                      color: Colors.transparent,
                                                      width: 0.7,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topRight:
                                                          Radius.circular(73),
                                                      topLeft:
                                                          Radius.circular(73),
                                                      bottomLeft:
                                                          Radius.circular(73),
                                                      bottomRight:
                                                          Radius.circular(73),
                                                    ) //                 <--- border radius here
                                                    ),
                                                child: InkWell(
                                                  onTap: () {
                                                    setState(() {
                                                      varDepartment =
                                                          varDepartment2
                                                              .toString();
                                                    });

                                                    print(varDepartment);
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              RecordMissing(
                                                                  notes,
                                                                  varDepartment)),
                                                    );
                                                  },
                                                  hoverColor: Color(0xff047c54),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 22.0,
                                                            right: 52,
                                                            bottom: 22),
                                                    child: Container(
                                                      width: widthSize - 35,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: <Widget>[
                                                          Row(
                                                            children: [
                                                              Text(
                                                                  " تسجيل المفقودات",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          17)),
                                                              SizedBox(
                                                                  width: 12),
                                                              Icon(
                                                                  Icons.person),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              InkWell(
                                                hoverColor: Color(0xff047c54),
                                                onTap: () {
                                                  //print(doQueryByName.toString());
                                                  print("contact us");
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            ContactusPage()),
                                                  );
                                                },
                                                child: Container(
                                                  width: widthSize - 35,
                                                  height: 77,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 22.0,
                                                            right: 52,
                                                            bottom: 22),
                                                    child: Container(
                                                      width: widthSize - 35,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: <Widget>[
                                                          Text(
                                                              " للتواصل والدعم",
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      17)),
                                                          SizedBox(width: 12),
                                                          Icon(Icons.person),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),

                                              Container(
                                                width: widthSize - 35,
                                                height: 77,
                                                decoration: BoxDecoration(
                                                    color: Colors.transparent,
                                                    border: Border.all(
                                                      color: Colors.transparent,
                                                      width: 0.7,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topRight:
                                                          Radius.circular(73),
                                                      topLeft:
                                                          Radius.circular(73),
                                                      bottomLeft:
                                                          Radius.circular(73),
                                                      bottomRight:
                                                          Radius.circular(73),
                                                    ) //                 <--- border radius here
                                                    ),
                                                child: InkWell(
                                                  onTap: () {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              UserPage()),
                                                    );
                                                  },
                                                  hoverColor: Color(0xff047c54),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 22.0,
                                                            right: 52,
                                                            bottom: 22),
                                                    child: Container(
                                                      width: widthSize - 35,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: <Widget>[
                                                          Row(
                                                            children: [
                                                              Text(
                                                                  " دليل المستخدم",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          17)),
                                                              SizedBox(
                                                                  width: 12),
                                                              Icon(
                                                                  Icons.person),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),

                                              /// userData is above and it's ending here
                                              /// /// userData is above and it's ending here
                                              /// /// userData is above and it's ending here
                                              Container(
                                                width: widthSize - 35,
                                                height: 77,
                                                decoration: BoxDecoration(
                                                    color: Colors.transparent,
                                                    border: Border.all(
                                                      color: Colors.transparent,
                                                      width: 0.7,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topRight:
                                                          Radius.circular(73),
                                                      topLeft:
                                                          Radius.circular(73),
                                                      bottomLeft:
                                                          Radius.circular(73),
                                                      bottomRight:
                                                          Radius.circular(73),
                                                    ) //                 <--- border radius here
                                                    ),
                                                child: InkWell(
                                                  onTap: () {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              RoyalOrder()),
                                                    );
                                                  },
                                                  hoverColor: Color(0xff047c54),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 22.0,
                                                            right: 52,
                                                            bottom: 22),
                                                    child: Container(
                                                      width: widthSize - 35,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: <Widget>[
                                                          Row(
                                                            children: [
                                                              Text(
                                                                  " الأمر السامي",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          17)),
                                                              SizedBox(
                                                                  width: 12),
                                                              Icon(
                                                                  Icons.person),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: widthSize - 35,
                                                height: 77,
                                                decoration: BoxDecoration(
                                                    color: Colors.transparent,
                                                    border: Border.all(
                                                      color: Colors.transparent,
                                                      width: 0.7,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topRight:
                                                          Radius.circular(73),
                                                      topLeft:
                                                          Radius.circular(73),
                                                      bottomLeft:
                                                          Radius.circular(73),
                                                      bottomRight:
                                                          Radius.circular(73),
                                                    ) //                 <--- border radius here
                                                    ),
                                                child: InkWell(
                                                  onTap: () {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              ExitPage()),
                                                    );
                                                  },
                                                  hoverColor: Color(0xff047c54),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 22.0,
                                                            right: 52,
                                                            bottom: 22),
                                                    child: Container(
                                                      width: widthSize - 35,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: <Widget>[
                                                          Row(
                                                            children: [
                                                              Text(
                                                                  " تسجيل خروج",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          17)),
                                                              SizedBox(
                                                                  width: 12),
                                                              Icon(
                                                                  Icons.logout),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),

                                    /// the endDrawer ends above
                                    /// the endDrawer ends above
                                    /// The end drawer ends above

                                    // This trailing comma makes auto-formatting nicer for build methods.
                                  ),
                                );
                              });
                        }
                    }
                  }),
            ),

            // sliverBox ends here
          ],
        ),
      ),
    );
  }

  Future<void> saveTodo(String title) async {
    final todo = ParseObject('Todo')
      ..set('title', title)
      ..set('done', false);
    await todo.save();
  }

  Future<List<ParseObject>> getTodo() async {
    QueryBuilder<ParseObject> queryTodo =
        QueryBuilder<ParseObject>(ParseObject('Missings'));
    final ParseResponse apiResponse = await queryTodo.query();

    if (apiResponse.success && apiResponse.results != null) {
      return apiResponse.results as List<ParseObject>;
    } else {
      return [];
    }
  }

  Future<void> updateTodo(String id, bool done) async {
    await Future.delayed(Duration(seconds: 1), () {});
  }

  Future<void> deleteTodo(String id) async {
    var todo = ParseObject('Todo')..objectId = id;
    await todo.delete();
  }

  check(varTitle) {
    if (varTitle.toString() == "aa")
      return Text("yummy");
    else
      return Text("yak");
  }
} // Class _Todo ends here
// choose file
