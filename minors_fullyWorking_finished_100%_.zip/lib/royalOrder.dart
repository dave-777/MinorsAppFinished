//import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:minors/contactus.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:url_launcher/link.dart';
import 'package:url_launcher/url_launcher.dart';
import 'RecordMissing.dart';

import 'connectToDBCode.dart';
import 'exit.dart';
import 'main.dart';
import 'profile.dart';
import 'userPage.dart';

final Uri _url = Uri.parse(
    'http://eportal.wilayah.gov.sa/SocialSearch.Api/HighOrder/HighOrder.pdf');

class RoyalOrder extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Stateful Clicker Counter',
      theme: ThemeData(
        // Application theme data, you can set the colors for the application as
        // you want
        primarySwatch: Colors.grey,
      ),
      home: RoyalOrderPage(title: 'Flutter Demo Clicker Counter Home Page'),
    );
  }
}

class RoyalOrderPage extends StatefulWidget {
  final String title;
  const RoyalOrderPage({Key? key, required this.title}) : super(key: key);

  @override
  _RoyalOrderPageState createState() => _RoyalOrderPageState();
}

class _RoyalOrderPageState extends State<RoyalOrderPage> {
  List<ParseObject> results = <ParseObject>[];

  @override
  Widget build(BuildContext context) {
    // String emailFirst = "munaif.abdulaziz@wilayah.gov.sa";
    // String secondEmail = "anqari.sulaiman@wilayah.gov.sa";
    // String thirdEmail = "alharby.abdulaziz@wilayah.gov.sa";
    double widthSize = MediaQuery.of(context).size.width;
    double heightSize = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Color(0xffffffff),
      // Color(0xf2f6f4f4),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              backgroundColor: Colors.white,
              foregroundColor: Colors.black,
              //Color(0xff493636),
              // Color(0xffffffff),
              leadingWidth: 72,
              leading: Padding(
                padding: const EdgeInsets.only(left: 0.8),
                child: IconButton(
                  icon: Icon(
                    Icons.person,
                    color: Colors.black,
                    size: 30.0,
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Profile()),
                    );
                  },
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Container(
                margin: EdgeInsets.only(top: 122),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                  topRight: Radius.circular(73),
                  topLeft: Radius.circular(13),
                )),
                width: widthSize,
                child: Column(

                    // fit: StackFit.passthrough,
                    //alignment: Alignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      InkWell(
                        onTap: (() {
                          // launchWeb();
                          _launchUrl();
                          print("cool");
                        }),
                        child: Container(
                          width: widthSize - 35,
                          height: 72,
                          decoration: BoxDecoration(
                              color: Color(0xff7a7474),
                              border: Border.all(
                                // color: Colors.white,
                                width: 0.07,
                              ),
                              borderRadius: BorderRadius.only(
                                //   topRight: Radius.circular(13),
                                //  topLeft: Radius.circular(13),
                                bottomLeft: Radius.circular(23),
                                bottomRight: Radius.circular(23),
                                topLeft: Radius.circular(23),
                                topRight: Radius.circular(23),
                              ) //                 <--- border radius here
                              ),
                          child: Center(
                              child: Text(
                            "الأمر السامي",
                            style: TextStyle(color: Colors.white),
                          )),
                        ),
                      ),

                      // above is the end of the last image row container
                      // above is the end of the last image row container
                      //
                      //

// here
// here
// here
// here
// here
                      Container(
                        margin: EdgeInsets.only(top: 27),
                        alignment: Alignment.center,
                        child: Text(
                            "  الهيئة العامة للولاية على أموال القاصرين ومن في حكمهم @",
                            style: TextStyle(color: Color(0xff878687))),
                      ),

                      Container(
                        margin: EdgeInsets.only(top: 2),
                        alignment: Alignment.center,
                        child: Text(
                          "  2022",
                          style: TextStyle(color: Color(0xff878687)),
                        ),
                      ),
                      // the parent column ends below
                      // the parent column ends below
                    ]),
              ),
            ),
          ],
        ),
      ),

////////////////////////////////////////
// the endDrawer is below
///////////////////////////////////////
      endDrawer: Container(
        padding: EdgeInsets.only(top: 7, left: 7, right: 7),
        child: Drawer(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Image.asset("images/title.JPG"),
              Container(
                width: widthSize - 35,
                height: 77,
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(
                      color: Colors.transparent,
                      width: 0.7,
                    ),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(73),
                      topLeft: Radius.circular(73),
                      bottomLeft: Radius.circular(73),
                      bottomRight: Radius.circular(73),
                    ) //                 <--- border radius here
                    ),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HomePage()),
                    );
                  },
                  hoverColor: Color(0xff047c54),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Row(
                            children: [
                              Text(" الرئيسية", style: TextStyle(fontSize: 17)),
                              SizedBox(width: 12),
                              Icon(Icons.home_max_outlined),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                width: widthSize - 35,
                height: 77,
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(
                      color: Colors.transparent,
                      width: 0.7,
                    ),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(73),
                      topLeft: Radius.circular(73),
                      bottomLeft: Radius.circular(73),
                      bottomRight: Radius.circular(73),
                    ) //                 <--- border radius here
                    ),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              RecordMissing(notes, varDepartment)),
                    );
                  },
                  hoverColor: Color(0xff047c54),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Row(
                            children: [
                              Text(" تسجيل المفقودات",
                                  style: TextStyle(fontSize: 17)),
                              SizedBox(width: 12),
                              Icon(Icons.person),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              InkWell(
                hoverColor: Color(0xff047c54),
                onTap: () {
                  //print(doQueryByName.toString());
                  print("contact us");
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ContactusPage()),
                  );
                },
                child: Container(
                  width: widthSize - 35,
                  height: 77,
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Text(" للتواصل والدعم",
                              style: TextStyle(fontSize: 17)),
                          SizedBox(width: 12),
                          Icon(Icons.person),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              Container(
                width: widthSize - 35,
                height: 77,
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(
                      color: Colors.transparent,
                      width: 0.7,
                    ),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(73),
                      topLeft: Radius.circular(73),
                      bottomLeft: Radius.circular(73),
                      bottomRight: Radius.circular(73),
                    ) //                 <--- border radius here
                    ),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => UserPage()),
                    );
                  },
                  hoverColor: Color(0xff047c54),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Row(
                            children: [
                              Text(" دليل المستخدم",
                                  style: TextStyle(fontSize: 17)),
                              SizedBox(width: 12),
                              Icon(Icons.person),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              /// userData is above and it's ending here
              /// /// userData is above and it's ending here
              /// /// userData is above and it's ending here
              Container(
                width: widthSize - 35,
                height: 77,
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(
                      color: Colors.transparent,
                      width: 0.7,
                    ),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(73),
                      topLeft: Radius.circular(73),
                      bottomLeft: Radius.circular(73),
                      bottomRight: Radius.circular(73),
                    ) //                 <--- border radius here
                    ),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => RoyalOrder()),
                    );
                  },
                  hoverColor: Color(0xff047c54),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Row(
                            children: [
                              Text(" الأمر السامي",
                                  style: TextStyle(fontSize: 17)),
                              SizedBox(width: 12),
                              Icon(Icons.person),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                width: widthSize - 35,
                height: 77,
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(
                      color: Colors.transparent,
                      width: 0.7,
                    ),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(73),
                      topLeft: Radius.circular(73),
                      bottomLeft: Radius.circular(73),
                      bottomRight: Radius.circular(73),
                    ) //                 <--- border radius here
                    ),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ExitPage()),
                    );
                  },
                  hoverColor: Color(0xff047c54),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Row(
                            children: [
                              Text(" تسجيل خروج",
                                  style: TextStyle(fontSize: 17)),
                              SizedBox(width: 12),
                              Icon(Icons.logout),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),

      /// the endDrawer ends above
      /// the endDrawer ends above
      /// The end drawer ends above

      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  void doQueryByName() async {
    // Create your query
    final QueryBuilder<ParseObject> parseQuery =
        QueryBuilder<ParseObject>(ParseObject('Profile'));

    // `whereContains` is a basic query method that checks if string field
    // contains a specific substring
    parseQuery.whereContains('name', 'Adam');

    // The query will resolve only after calling this method, retrieving
    // an array of `ParseObjects`, if success
    final ParseResponse apiResponse = await parseQuery.query();

    if (apiResponse.success && apiResponse.results != null) {
      // Let's show the results
      for (var o in apiResponse.results!) {
        print((o as ParseObject).toString());
        print("hoha");
      }

      setState(() {
        results = apiResponse.results as List<ParseObject>;
      });
    } else {
      results = [];
    }
  }
}

Future<void> _launchUrl() async {
  if (!await launchUrl(_url)) {
    throw 'Could not launch $_url';
  }
}
