// ignore_for_file: prefer_const_constructors

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

// ignore_for_file: prefer_const_constructors

import 'dart:async';

import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:minors/RecordMissingDetails.dart';
import 'package:minors/main.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import 'RecordMissing.dart';
import 'contactus.dart';
import 'exit.dart';
import 'profile.dart';
import 'royalOrder.dart';
import 'userPage.dart';

const List<String> firstList = <String>[
  '...اختر...',
];

const List<String> yearsList = <String>[
  '...اختر...',
  '2015',
  '2016',
  '2017',
  '2018',
  '2019',
  '2020',
  '2021',
  '2022',
];

const List<String> notiTypeList = <String>[
  '...اختر...',
  'تحويل نقدي',
  'افصاح ',
];

String? department;
String? year;
String? notiType;
String? transferNum;
String? transferAmount;
String? transferedToDep;
//String? note;

File? uploadedImage;
String? moneyTransfer;

int numOfRows = 0;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
/*
  final keyApplicationId = '9XglgwXJxUZdUyIRD0EzrYy7s5bsaRFXlIU7RSzT';
  final keyClientKey = 'DNcLbgsWWNqhCS3VuC9pH4qSInr1xCtLIsSBn39N';
  final keyParseServerUrl = 'https://parseapi.back4app.com';

  await Parse().initialize(keyApplicationId, keyParseServerUrl,
      clientKey: keyClientKey, debug: true);
*/
  final keyApplicationId = '9XglgwXJxUZdUyIRD0EzrYy7s5bsaRFXlIU7RSzT';
  final keyClientKey = 'DNcLbgsWWNqhCS3VuC9pH4qSInr1xCtLIsSBn39N';
  final keyParseServerUrl = 'https://parseapi.back4app.com';

  await Parse().initialize(keyApplicationId, keyParseServerUrl,
      clientKey: keyClientKey, debug: true);
  runApp(MaterialApp(
    home: RecordMissingBody(),
  ));
}

class RecordMissing extends StatelessWidget {
  // This widget is the root of your application.
  //

  RecordMissing(
    notes,
    varDepartment,
  );

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Stateful Clicker Counter',
      theme: ThemeData(
        // Application theme data, you can set the colors for the application as
        // you want
        primarySwatch: Colors.grey,
      ),
      home: RecordMissingBody(),
    );
  }
}

class RecordMissingBody extends StatefulWidget {
  @override
  _RecordMissingBodyState createState() => _RecordMissingBodyState();
}

class _RecordMissingBodyState extends State<RecordMissingBody> {
  final todoController = TextEditingController();
  List<ParseObject> results = <ParseObject>[];
  final GlobalKey<FormState> _Formkey = GlobalKey<FormState>();

  final todoControllerNote = TextEditingController();
  final todoControllerTransferAmount = TextEditingController();
  final todoControllerTransferNum = TextEditingController();

  //List<ParseObject> results = <ParseObject>[];
  String dropdownValue = '...اختر...';
  String dropdownValue2 = '...اختر...';
  String dropdownValue3 = '...اختر...';
  String dropdownValue4 = '...اختر...';
  String dropdownValue5 = '...اختر...';
  String dropdownValue6 = '...اختر...';
  String dropdownValue7 = '...اختر...';

  //List<ParseObject> results = <ParseObject>[];
  //
  //String dropdownValue = yearsList.first;
  List<ParseObject?> dropdownItems = <ParseObject?>[];

  FilePickerResult? result;
  String? _fileName;
  PlatformFile? pickedFile;
  bool isLoading = false;
  File? fileToDisplay;
  bool isVisible = true;
  //final GlobalKey<FormState> _Formkey = GlobalKey<FormState>();
  //
  //

  void readData() async {
    var apiResponse = await ParseObject('Todo').getAll();
    if (apiResponse.success) {
      for (var myObject in apiResponse.result) {
        debugPrint(" OBJECT: " + myObject.get<String>('Department')!);
        print("yay ");
        dropdownItems.add(myObject);
      }
      setState(() {});
    } else {
      print("can't connect to DB ");
    }
    @override
    void initState() {
      super.initState();
      readData();
      print("barb is kokay");
    }
  }

  void PickFile() async {
    try {
      setState(() {
        isLoading = true;
      });

      result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['png', 'pdf', 'jpg', 'xlsx'],
        allowMultiple: false,
      );

      if (result != null) {
        _fileName = result!.files.first.name;
        pickedFile = result!.files.first;
        fileToDisplay = File(pickedFile!.path.toString());

        print("FileName: $_fileName");
      }
      setState(() {
        isLoading = false;
      });
    } catch (e) {
      print(e);
    }
  }

  void addToDo() async {
    if (todoController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Empty title"),
        duration: Duration(seconds: 2),
      ));
      return;
    }
    await saveTodo(todoController.text);
    setState(() {
      todoController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    double widthSize = MediaQuery.of(context).size.width;
    double heightSize = MediaQuery.of(context).size.height;
    String selectText = "اختر";

    return Container(
      // height: 1777,
      width: MediaQuery.of(context).size.width,
      child: Scaffold(
          appBar: AppBar(
            foregroundColor: Color(0xff000000),
            title: Text("قائمة البلاغات"),
            backgroundColor: Color(0xffffffff),
            leading: Padding(
              padding: const EdgeInsets.only(left: 0.8),
              child: IconButton(
                icon: Icon(
                  Icons.home,
                  color: Color(0xff000000),
                  size: 30.0,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomePage()),
                  );
                },
              ),
            ),
            centerTitle: true,
          ),
          body: SingleChildScrollView(
            child: Column(children: <Widget>[
              Container(
                  padding: EdgeInsets.fromLTRB(17.0, 1.0, 7.0, 1.0),
                  child: Column(
                    children: [
                      ////////// here
                      ///   here
                      /// form is below
                      /// form
                      /// form
                      /// form
                      /// form
                      /// form
                      /// form is
                      Form(
                        child: Container(
                          margin: EdgeInsets.only(top: 22),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                            topRight: Radius.circular(73),
                            topLeft: Radius.circular(13),
                            bottomRight: Radius.circular(73),
                            bottomLeft: Radius.circular(13),
                          )),
                          width: widthSize,
                          child: Column(
                            // fit: StackFit.passthrough,
                            //alignment: Alignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: widthSize,
                                // height: 588,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(23),
                                    topLeft: Radius.circular(23),
                                    bottomLeft: Radius.circular(0),
                                    bottomRight: Radius.circular(0),
                                  ),
                                ),
                                // color: Colors.white,
                              ),

                              // above is the end of the first muliti Select Field row container
                              // above is the end of the last muliti Select Field  row container
                              //
                              //
                              //
                              /// body white container starts here
                              Container(
                                color: Colors.white,
                                padding: EdgeInsets.all(17),
                                width: widthSize - 35,
                                child: Column(
                                  children: [
                                    ///
                                    ///
                                    ///
                                    ///
                                    ///
                                    Container(
                                      margin: EdgeInsets.all(12),
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        "الجهة",
                                        textDirection: TextDirection.rtl,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                    // DropdownButton below
                                    // DropdownButton below
                                    // DropdownButton below
                                    Directionality(
                                      textDirection: TextDirection.rtl,
                                      child: Container(
                                        alignment: Alignment.center,
                                        // margin: EdgeInsets.only(top: 7),
                                        width: widthSize - 68,
                                        decoration: BoxDecoration(
                                          color: Color(0xffe8e8e8),
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(27),
                                            topLeft: Radius.circular(27),
                                            bottomLeft: Radius.circular(27),
                                            bottomRight: Radius.circular(27),
                                          ),
                                        ),
                                        child: DropdownButton<String>(
                                          // Step 3.

                                          value: dropdownValue,
                                          onChanged: (String? value) {
                                            setState(() {
                                              dropdownValue = value!;
                                              department = dropdownValue;
                                              print(dropdownValue);
                                            });
                                          },
                                          // Step 4.
                                          items:
                                              //varDepartment2!

                                              <String>[
                                            '...اختر...',
                                            ' "الأمن العام  "المرور',
                                          ]

                                                  // notiTypeList
                                                  .map<
                                                          DropdownMenuItem<
                                                              String>>(
                                                      (String value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Container(
                                                margin:
                                                    EdgeInsets.only(right: 122),
                                                child: Text(
                                                  value,
                                                  style:
                                                      TextStyle(fontSize: 17),
                                                ),
                                              ),
                                            );
                                          }).toList(),
                                        ),
                                      ),
                                    ),
                                    // notes row is below //
                                    // // notes row is below
                                    // // notes row is below
                                    // // notes row is below
                                    // // notes row is below
                                    // // notes row is below
                                    //
                                    Container(
                                      margin: EdgeInsets.all(12),
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        "777السنة",
                                        textDirection: TextDirection.rtl,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                    Directionality(
                                      textDirection: TextDirection.rtl,
                                      child: Container(
                                        alignment: Alignment.center,
                                        // margin: EdgeInsets.only(top: 7),
                                        width: widthSize - 68,
                                        decoration: BoxDecoration(
                                          color: Color(0xffe8e8e8),
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(27),
                                            topLeft: Radius.circular(27),
                                            bottomLeft: Radius.circular(27),
                                            bottomRight: Radius.circular(27),
                                          ),
                                        ),
                                        child: DropdownButton<String>(
                                          // Step 3.

                                          value: dropdownValue2,
                                          onChanged: (String? value2) {
                                            setState(() {
                                              dropdownValue2 = value2!;
                                              year = dropdownValue2;
                                              print(dropdownValue2);
                                            });
                                          },
                                          // Step 4.
                                          items:
                                              //varDepartment2!

                                              <String>[
                                            '...اختر...',
                                            '2015',
                                            '2016',
                                            '2017',
                                            '2018                    ',
                                            '2019',
                                            '2020',
                                            '2021',
                                            '2022',
                                          ]

                                                  // yearsList
                                                  .map<
                                                          DropdownMenuItem<
                                                              String>>(
                                                      (String value2) {
                                            return DropdownMenuItem<String>(
                                              value: value2,
                                              child: Container(
                                                margin:
                                                    EdgeInsets.only(right: 122),
                                                child: Text(
                                                  value2,
                                                  style:
                                                      TextStyle(fontSize: 17),
                                                ),
                                              ),
                                            );
                                          }).toList(),
                                        ),
                                      ),
                                    ),

                                    ///  /// amount ends here
                                    ///  /// amount ends here
                                    ///
/*
                                  Container(
                                    height: 255,
                                    width: 255,
                                    color: Colors.red,
                                    child: DropdownButton<String>(
                                        items: ['lol', 'ggg'],
                                        
                                        dropdownItems
                                            .map((ParseObject? value) {
                                          return DropdownMenuItem<String>(
                                            value: value!
                                                .get<String>("Department")!,
                                            child: Text(value
                                                .get<String>("Department")!),
                                          );
                                        }).toList(),
                                         onChanged: (_) {}),
                                  ),
                                  */

                                    // notes row is below //
                                    // // notes row is below
                                    // // notes row is below
                                    // // notes row is below
                                    // // notes row is below
                                    // // notes row is below

                                    Container(
                                      margin: EdgeInsets.all(12),
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        "نوع الاشعار",
                                        textDirection: TextDirection.rtl,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),

                                    Directionality(
                                      textDirection: TextDirection.rtl,
                                      child: Container(
                                        alignment: Alignment.center,
                                        // margin: EdgeInsets.only(top: 7),
                                        width: widthSize - 68,
                                        decoration: BoxDecoration(
                                          color: Color(0xffe8e8e8),
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(27),
                                            topLeft: Radius.circular(27),
                                            bottomLeft: Radius.circular(27),
                                            bottomRight: Radius.circular(27),
                                          ),
                                        ),
                                        child: DropdownButton<String>(
                                          // Step 3.

                                          value: dropdownValue3,
                                          onChanged: (String? value3) {
                                            setState(() {
                                              dropdownValue3 = value3!;
                                              notiType = value3;
                                              print("here " + dropdownValue3);
                                            });
                                          },
                                          // Step 4.
                                          items:
                                              //varDepartment2!

                                              <String>[
                                            '...اختر...',
                                            'تحويل نقدي',
                                            'افصاح عن سنوات سابقة',
                                          ]

                                                  // yearsList
                                                  .map<
                                                          DropdownMenuItem<
                                                              String>>(
                                                      (String value3) {
                                            return DropdownMenuItem<String>(
                                              value: value3,
                                              child: Container(
                                                margin:
                                                    EdgeInsets.only(right: 122),
                                                child: Text(
                                                  value3,
                                                  style:
                                                      TextStyle(fontSize: 17),
                                                ),
                                              ),
                                            );
                                          }).toList(),
                                        ),
                                      ),
                                    ),

                                    if (notiType == "تحويل نقدي")
                                      Container(
                                        padding: EdgeInsets.all(17),
                                        alignment: Alignment.centerRight,
                                        child: Text(
                                          "  رقم الحوالة ",
                                          textDirection: TextDirection.rtl,
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 17,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    if (notiType == "تحويل نقدي")
                                      Container(
                                        alignment: Alignment.center,
                                        // margin: EdgeInsets.only(top: 7),
                                        width: widthSize - 68,
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                            color: Colors.transparent,
                                            width: 0.7,
                                          ),
                                          color: Colors.white,
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(27),
                                            topLeft: Radius.circular(27),
                                            bottomLeft: Radius.circular(17),
                                            bottomRight: Radius.circular(17),
                                          ),
                                        ),
                                        child: TextFormField(
                                          controller: todoControllerTransferNum,
                                          onChanged: (value4) {
                                            setState(() {
                                              print(value4);
                                              value4 = todoControllerTransferNum
                                                  .text;
                                              transferNum = value4;
                                              print("kooooooooooo");
                                            });
                                            print(value4 + "stay awesome ");
                                          },
                                          textAlign: TextAlign.center,
                                          textDirection: TextDirection.rtl,
                                          decoration: InputDecoration(
                                              alignLabelWithHint: true,
                                              border: OutlineInputBorder(
                                                borderRadius: BorderRadius.only(
                                                  topRight: Radius.circular(17),
                                                  topLeft: Radius.circular(17),
                                                  bottomLeft:
                                                      Radius.circular(17),
                                                  bottomRight:
                                                      Radius.circular(17),
                                                ),
                                              ),
                                              labelText: 'الرقم',
                                              labelStyle: TextStyle()),
                                        ),
                                      ),

                                    if (notiType == "تحويل نقدي")
                                      Container(
                                        padding: EdgeInsets.all(17),
                                        alignment: Alignment.centerRight,
                                        child: Text(
                                          "  مبلغ الحوالة ",
                                          textDirection: TextDirection.rtl,
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 17,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    if (notiType == "تحويل نقدي")
                                      Container(
                                        alignment: Alignment.center,
                                        // margin: EdgeInsets.only(top: 7),
                                        width: widthSize - 68,
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                            color: Colors.transparent,
                                            width: 0.7,
                                          ),
                                          color: Colors.white,
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(27),
                                            topLeft: Radius.circular(27),
                                            bottomLeft: Radius.circular(17),
                                            bottomRight: Radius.circular(17),
                                          ),
                                        ),
                                        child: TextFormField(
                                          controller:
                                              todoControllerTransferAmount,
                                          onChanged: (value5) {
                                            setState(() {
                                              print(value5);
                                              value5 =
                                                  todoControllerTransferAmount
                                                      .text;
                                              transferAmount = value5;
                                              print("kooooooooooo");
                                            });
                                            print(value5 + "stay awesome ");
                                          },
                                          textAlign: TextAlign.center,
                                          textDirection: TextDirection.rtl,
                                          decoration: InputDecoration(
                                              alignLabelWithHint: true,
                                              border: OutlineInputBorder(
                                                borderRadius: BorderRadius.only(
                                                  topRight: Radius.circular(17),
                                                  topLeft: Radius.circular(17),
                                                  bottomLeft:
                                                      Radius.circular(17),
                                                  bottomRight:
                                                      Radius.circular(17),
                                                ),
                                              ),
                                              labelText: 'تحويل نقدي',
                                              labelStyle: TextStyle()),
                                        ),
                                      ),

                                    if (notiType == "تحويل نقدي")
                                      Container(
                                        padding: EdgeInsets.all(17),
                                        alignment: Alignment.centerRight,
                                        child: Text(
                                          "  الجهة المحول لها المبلغ  ",
                                          textDirection: TextDirection.rtl,
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 17,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),

                                    if (notiType == "تحويل نقدي")
                                      Directionality(
                                        textDirection: TextDirection.rtl,
                                        child: Container(
                                          alignment: Alignment.center,
                                          // margin: EdgeInsets.only(top: 7),
                                          //width: widthSize - 173,
                                          decoration: BoxDecoration(
                                            color: Color(0xffe8e8e8),
                                            borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(27),
                                              topLeft: Radius.circular(27),
                                              bottomLeft: Radius.circular(27),
                                              bottomRight: Radius.circular(27),
                                            ),
                                          ),
                                          child: DropdownButton<String>(
                                            // Step 3.

                                            value: dropdownValue7,
                                            onChanged: (String? value6) {
                                              setState(() {
                                                dropdownValue7 = value6!;
                                                transferedToDep = value6;
                                                print(
                                                    "here is dep to transfer to " +
                                                        transferedToDep!);
                                              });
                                            },
                                            // Step 4.
                                            items:
                                                //varDepartment2!

                                                <String>[
                                              '...اختر...',
                                              'الهيئة العامه للولاية',
                                            ]

                                                    // yearsList
                                                    .map<
                                                            DropdownMenuItem<
                                                                String>>(
                                                        (String value6) {
                                              return DropdownMenuItem<String>(
                                                value: value6,
                                                child: Container(
                                                  margin: EdgeInsets.only(
                                                      right: 122),
                                                  child: Text(
                                                    value6,
                                                    style:
                                                        TextStyle(fontSize: 17),
                                                  ),
                                                ),
                                              );
                                            }).toList(),
                                          ),
                                        ),
                                      ),

                                    Container(
                                      padding: EdgeInsets.all(17),
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        "  ملاحظات ",
                                        textDirection: TextDirection.rtl,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),

                                    Container(
                                      alignment: Alignment.center,
                                      // margin: EdgeInsets.only(top: 7),
                                      width: widthSize - 68,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Colors.transparent,
                                          width: 0.7,
                                        ),
                                        color: Colors.white,
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(27),
                                          topLeft: Radius.circular(27),
                                          bottomLeft: Radius.circular(17),
                                          bottomRight: Radius.circular(17),
                                        ),
                                      ),
                                      child: TextFormField(
                                        controller: todoControllerNote,
                                        onChanged: (value7) {
                                          setState(() {
                                            print(value7);
                                            value7 = todoControllerNote.text;
                                            note = value7;
                                            print("kooooooooooo");
                                          });
                                          print(value7 +
                                              " This is the note TextField ");
                                        },
                                        textAlign: TextAlign.center,
                                        textDirection: TextDirection.rtl,
                                        decoration: InputDecoration(
                                            alignLabelWithHint: true,
                                            border: OutlineInputBorder(
                                              borderRadius: BorderRadius.only(
                                                topRight: Radius.circular(17),
                                                topLeft: Radius.circular(17),
                                                bottomLeft: Radius.circular(17),
                                                bottomRight:
                                                    Radius.circular(17),
                                              ),
                                            ),
                                            labelText: 'ملاحظات',
                                            labelStyle: TextStyle()),
                                      ),
                                    ),

                                    /// notes ends here
                                    ///  /// notes ends here
                                    ///  /// notes ends here

                                    // below is the start of the TextButton to upload files
                                    // below is the start of the TextButton to upload files
                                    // below is the start of the TextButton to upload files

                                    Container(
                                      margin: EdgeInsets.only(
                                          left: 7, right: 7, top: 22),
                                      padding:
                                          EdgeInsets.only(left: 7, right: 7),
                                      child: isLoading
                                          ? CircularProgressIndicator()
                                          : TextButton(
                                              onPressed: () {
                                                PickFile();
                                              },
                                              child: Column(
                                                children: [
                                                  Container(
                                                    alignment:
                                                        Alignment.centerRight,
                                                    width: widthSize + 77,
                                                    padding: EdgeInsets.only(
                                                      top: 7,
                                                      bottom: 7,
                                                    ),
                                                    child: Text(
                                                      "(img,excel,pdf) حجم الملف 20 ميجا بايت وبصيغة ",
                                                      style: TextStyle(
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                  Container(
                                                      decoration: BoxDecoration(
                                                        border: Border.all(
                                                          color: Colors.grey,
                                                          width: 0.7,
                                                        ),
                                                        color:
                                                            Color(0xff038447),
                                                        borderRadius:
                                                            BorderRadius.only(
                                                          topRight:
                                                              Radius.circular(
                                                                  17),
                                                          topLeft:
                                                              Radius.circular(
                                                                  17),
                                                          bottomLeft:
                                                              Radius.circular(
                                                                  17),
                                                          bottomRight:
                                                              Radius.circular(
                                                                  17),
                                                        ),
                                                      ),
                                                      padding: EdgeInsets.only(
                                                        left: 7,
                                                        right: 17,
                                                      ),
                                                      margin: EdgeInsets.only(
                                                        left: 17,
                                                        right: 17,
                                                      ),
                                                      height: 37,
                                                      width: 197,
                                                      alignment:
                                                          Alignment.center,
                                                      // color: Color(0xff038447),
                                                      child: Row(
                                                        children: [
                                                          Text(
                                                            "No File is...",
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .white),
                                                          ),
                                                          Container(
                                                            color: Colors.white,
                                                            margin:
                                                                EdgeInsets.only(
                                                              top: 1,
                                                              bottom: 1,
                                                              left: 3,
                                                              right: 3,
                                                            ),
                                                            width: 3,
                                                            child:
                                                                // if(pickedFile != null)
                                                                SizedBox(
                                                              height: 50,
                                                              width: 100,
                                                            ),
                                                          ),
                                                          Container(
                                                            padding:
                                                                EdgeInsets.only(
                                                              left: 17,
                                                              right: 3,
                                                            ),
                                                            child: Text(
                                                              "Choose File",
                                                              style: TextStyle(
                                                                  color: Color(
                                                                      0xffa9a7a7)),
                                                            ),
                                                          ),
                                                        ],
                                                      )),
                                                ],
                                              ),
                                            ),
                                    ),
                                    if (pickedFile != null)
                                      Container(
                                        margin: EdgeInsets.all(7),
                                        padding: EdgeInsets.all(7),
                                        child: SizedBox(
                                          height: 50,
                                          width: 100,
                                          child: Column(
                                            children: [
                                              Text(_fileName!),
                                              SizedBox(height: 7),
                                              Image.file(fileToDisplay!),
                                            ],
                                          ),
                                        ),
                                      ),

                                    Container(
                                      margin: EdgeInsets.only(
                                          left: 12, top: 22, bottom: 12),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                                height: 37,
                                                width: 62,
                                                decoration: BoxDecoration(
                                                  border: Border.all(
                                                    color: Colors.grey,
                                                    width: 0.7,
                                                  ),
                                                  color: Color(0xff038447),
                                                  borderRadius:
                                                      BorderRadius.only(
                                                    topRight:
                                                        Radius.circular(17),
                                                    topLeft:
                                                        Radius.circular(17),
                                                    bottomLeft:
                                                        Radius.circular(17),
                                                    bottomRight:
                                                        Radius.circular(17),
                                                  ),
                                                ),
                                                alignment: Alignment.center,
                                                margin: EdgeInsets.only(
                                                    top: 12, right: 12),
                                                //  color: Color(0xff038447),
                                                child: TextButton(
                                                    onPressed: () {},
                                                    child: Text(
                                                      "الغاء",
                                                      style: TextStyle(
                                                          color: Colors.white,
                                                          fontWeight:
                                                              FontWeight.bold),
                                                    ))),
                                            Container(
                                              height: 37,
                                              width: 62,
                                              decoration: BoxDecoration(
                                                border: Border.all(
                                                  color: Colors.grey,
                                                  width: 0.7,
                                                ),
                                                color: Color(0xff038447),
                                                borderRadius: BorderRadius.only(
                                                  topRight: Radius.circular(17),
                                                  topLeft: Radius.circular(17),
                                                  bottomLeft:
                                                      Radius.circular(17),
                                                  bottomRight:
                                                      Radius.circular(17),
                                                ),
                                              ),
                                              alignment: Alignment.center,
                                              margin: EdgeInsets.only(top: 12),
                                              //color: Color(0xff038447),
                                              child: TextButton(
                                                  onPressed: () async {
                                                    Future.delayed(
                                                        Duration(
                                                            milliseconds: 1000),
                                                        () {
                                                      // Do something

                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (context) =>
                                                                RecordMissingBody()),
                                                      );
                                                    });

                                                    if (transferAmount !=
                                                            null &&
                                                        transferNum != null &&
                                                        _fileName != null) {
                                                      var firstObject =
                                                          ParseObject(
                                                              'Missings')
                                                            ..set('Department',
                                                                department)
                                                            ..set('Year', year)
                                                            ..set('FileName',
                                                                _fileName)
                                                            ..set(
                                                                'TransferNumber',
                                                                transferNum)
                                                            ..set(
                                                                'TranferToDepartmentName',
                                                                transferedToDep)
                                                            ..set(
                                                                'TransferAmount',
                                                                transferAmount)
                                                            ..set('NotiType',
                                                                notiType)
                                                            ..set(
                                                                'Notes', note);
                                                      await firstObject.save();
                                                      print(
                                                          'done ' + notiType!);
                                                    } else if (_fileName ==
                                                        null) {
                                                      var firstObject =
                                                          ParseObject(
                                                              'Missings')
                                                            ..set('Department',
                                                                department)
                                                            ..set('Year', year)
                                                            ..set('FileName',
                                                                '_fileName')
                                                            ..set(
                                                                'TransferNumber',
                                                                transferNum)
                                                            ..set(
                                                                'TranferToDepartmentName',
                                                                transferedToDep)
                                                            ..set(
                                                                'TransferAmount',
                                                                transferAmount)
                                                            ..set('NotiType',
                                                                notiType)
                                                            ..set(
                                                                'Notes', note);
                                                      await firstObject.save();
                                                    } else {
                                                      // _fileName
                                                      var firstObject =
                                                          ParseObject(
                                                              'Missings')
                                                            ..set('Department',
                                                                department)
                                                            ..set('Year', year)
                                                            ..set('FileName',
                                                                'fileToDisplay')
                                                            ..set(
                                                                'TransferNumber',
                                                                ' فارغ')
                                                            ..set(
                                                                'TranferToDepartmentName',
                                                                ' فارغ')
                                                            ..set(
                                                                'TransferAmount',
                                                                ' فارغ')
                                                            ..set('NotiType',
                                                                notiType)
                                                            ..set(
                                                                'Notes', note);
                                                      await firstObject.save();
                                                    }
                                                    if (!_Formkey.currentState!
                                                        .validate()) {
                                                      return;
                                                    }

                                                    Future.delayed(
                                                        Duration(
                                                            milliseconds: 3000),
                                                        () {
                                                      // Do something

                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (context) =>
                                                                RecordMissingBody()),
                                                      );
                                                    });
                                                    setState(() {
                                                      //isVisible = !isVisible;
                                                    });
                                                  },
                                                  child: Text(
                                                    "حفظ",
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  )),
                                            ),
                                          ]),
                                    ),

                                    // the horizantal ListView is below
                                    // // the horizantal ListView is below
                                    // // the horizantal ListView is below
                                    // // the horizantal ListView is below

                                    //// here is the conent ends
                                    /// here is the conent ends
                                    /// here is the conent ends
                                    /// here is the conent ends
                                    /// here is the conent ends
                                    /// here is the conent ends
                                    /// here is the conent ends
                                    /// here is the conent ends
                                    /// here is the conent ends
                                    ///

                                    // 3

                                    // 4

                                    // 6

                                    // 6
                                    // 9

                                    // the column end below is for the white background column
                                    //  // the column below is the white background column
                                    //  // the column below is the white background column
                                  ],
                                ),
                              ),

                              // sliverBox ends here
                            ],
                          ),
                        ),
                      ),

                      Row(
                        children: <Widget>[
                          SingleChildScrollView(
                            child: Column(
                              children: [
                                Container(
                                    margin: EdgeInsets.only(left: 2),
                                    padding: EdgeInsets.all(7),
                                    color: Color(0xff98a1bc),
                                    width:
                                        MediaQuery.of(context).size.width - 27,
                                    height: 77,
                                    child: ListView(
                                      scrollDirection: Axis.horizontal,
                                      children: [
                                        Row(
                                            textDirection: TextDirection.rtl,
                                            children: [
                                              Container(
                                                width: 77,
                                                child: Text("#",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                              ),
                                              Container(
                                                width: 177,
                                                child: Text("الرقم التشغيلي",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                              ),
                                              Container(
                                                width: 177,
                                                child: Text("الجهة ",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                              ),
                                              Container(
                                                width: 177,
                                                child: Text("الموظف ",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                              ),
                                              Container(
                                                width: 177,
                                                child: Text("السنة ",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                              ),
                                              Container(
                                                width: 177,
                                                child: Text("نوع الاشعار ",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                              ),
                                              Container(
                                                width: 177,
                                                child: Text(" رقم الحوالة ",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                              ),
                                              Container(
                                                width: 177,
                                                child: Text("  مبلغ الحوالة ",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                              ),
                                              Container(
                                                width: 177,
                                                child: Text("الجهة المحول لها ",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                              ),
                                            ]),
                                      ],
                                    )),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  )),
              Container(
                margin: EdgeInsets.only(left: 2),
                padding: EdgeInsets.all(7),
                color: Color(0xffdcdcdc),
                width: MediaQuery.of(context).size.width - 27,
                height:
                    //double.infinity,
                    550,
                child: Expanded(
                  child: FutureBuilder<List<ParseObject>>(
                      future: getTodo(),
                      builder: (context, snapshot) {
                        //  reverse:
                        //  true;
                        switch (snapshot.connectionState) {
                          case ConnectionState.none:
                          case ConnectionState.waiting:
                            return Center(
                              child: Container(
                                  width: 100,
                                  height: 100,
                                  child: CircularProgressIndicator()),
                            );
                          default:
                            if (snapshot.hasError) {
                              return Center(
                                child: Text("Error..."),
                              );
                            }
                            if (!snapshot.hasData) {
                              return Center(
                                child: Text("No Data..."),
                              );
                            } else {
                              return ListView.builder(
                                  //reverse: true,
                                  padding: EdgeInsets.only(top: 10.0),
                                  //reverse: true,
                                  itemCount:
                                      //5,
                                      snapshot.data!.length,
                                  itemBuilder: (context, index) {
                                    //*************************************
                                    //Get Parse Object Values
                                    //*************************************
                                    //Get Parse Object Values
                                    final varTodo = snapshot.data![index];
                                    final varDepartment =
                                        varTodo.get<String>('Department')!;
                                    final varTransferNum =
                                        varTodo.get<String>('TransferNumber')!;
                                    final varNotiType =
                                        varTodo.get<String>('NotiType')!;
                                    final varAmount =
                                        varTodo.get<String>('TransferAmount')!;
                                    final varToDep = varTodo.get<String>(
                                        'TranferToDepartmentName')!;
                                    final varYear =
                                        varTodo.get<String>('Year')!;

                                    // numOfRows below
                                    numOfRows = snapshot.data!.length;
                                    int i = 0;
                                    i++;

                                    //*************************************    //*************************************

                                    return Column(
                                      children: [
                                        ListTile(
                                          // title: Text(varTitle),

                                          title: Container(
                                              margin: EdgeInsets.only(left: 1),
                                              padding: EdgeInsets.all(7),
                                              color: Color(0xffd4dbed),
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width +
                                                  77,
                                              height: 77,
                                              child: ListView(
                                                scrollDirection:
                                                    Axis.horizontal,
                                                children: [
                                                  Row(
                                                      textDirection:
                                                          TextDirection.rtl,
                                                      children: [
                                                        Container(
                                                          width: 77,
                                                          child: Text("$index",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold)),
                                                        ),
                                                        Container(
                                                          width: 177,
                                                          child: Text(
                                                              " $varTransferNum ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold)),
                                                        ),
                                                        Container(
                                                          width: 177,
                                                          child: Text(
                                                              ' $varDepartment ',
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold)),
                                                        ),
                                                        Container(
                                                          width: 177,
                                                          child: Text("داوود ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold)),
                                                        ),
                                                        Container(
                                                          width: 177,
                                                          child: Text(
                                                              " $varYear ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold)),
                                                        ),
                                                        Container(
                                                          width: 177,
                                                          child: Text(
                                                              " $varNotiType ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold)),
                                                        ),
                                                        Container(
                                                          width: 177,
                                                          child: Text(
                                                              "$varTransferNum ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold)),
                                                        ),
                                                        Container(
                                                          width: 177,
                                                          child: Text(
                                                              "$varAmount ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold)),
                                                        ),
                                                        Container(
                                                          width: 177,
                                                          child: Text(
                                                              "$varToDep ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold)),
                                                        ),
                                                      ]),
                                                ],
                                              )),

                                          // trailing: Text("back"),
                                        ),
                                      ],
                                    );
                                  });
                            }
                        }
                      }),
                ),
              ),
            ]),
          )),
    );
  } // Widget Build context ends here

  Future<void> saveTodo(String title) async {
    final todo = ParseObject('Missings')
      ..set('title', title)
      ..set('done', false);
    await todo.save();
  }

  Future<List<ParseObject>> getTodo() async {
    QueryBuilder<ParseObject> queryTodo =
        QueryBuilder<ParseObject>(ParseObject('Missings'));
    final ParseResponse apiResponse = await queryTodo.query();

    if (apiResponse.success && apiResponse.results != null) {
      return apiResponse.results as List<ParseObject>;
    } else {
      return [];
    }
  }

  Future<void> updateTodo(String id, bool done) async {
    var todo = ParseObject('Todo')
      ..objectId = id
      ..set('done', done);
    await todo.save();
  }

  Future<void> deleteTodo(String id) async {
    var todo = ParseObject('Todo')..objectId = id;
    await todo.delete();
  }

  check(varTitle) {
    if (varTitle.toString() == "aa")
      return Text("yummy");
    else
      return Text("yak");
  }
} // Class _Todo ends here
