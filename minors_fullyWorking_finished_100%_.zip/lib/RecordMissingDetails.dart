// ignore_for_file: prefer_const_constructors

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

int numOfRows = 0;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Remember the grey out page that appears fo this page is because you re connect the connection

  final keyApplicationId = '9XglgwXJxUZdUyIRD0EzrYy7s5bsaRFXlIU7RSzT';
  final keyClientKey = 'DNcLbgsWWNqhCS3VuC9pH4qSInr1xCtLIsSBn39N';
  final keyParseServerUrl = 'https://parseapi.back4app.com';

  await Parse().initialize(keyApplicationId, keyParseServerUrl,
      clientKey: keyClientKey, debug: true);

  runApp(MaterialApp(
    home: RecordMissingDetails(),
  ));
}

class RecordMissingDetails extends StatefulWidget {
  @override
  _RecordMissingDetailsState createState() => _RecordMissingDetailsState();
}

class _RecordMissingDetailsState extends State<RecordMissingDetails> {
  final todoController = TextEditingController();
  final List<ParseObject> dropdownItems = <ParseObject>[];

  void addToDo() async {
    if (todoController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Empty title"),
        duration: Duration(seconds: 2),
      ));
      return;
    }
    await saveTodo(todoController.text);
    setState(() {
      todoController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        foregroundColor: Color(0xff000000),
        title: Text("قائمة بلاغات المفقودات"),
        backgroundColor: Color(0xffffffff),
        centerTitle: true,
      ),
      body: Column(
        children: <Widget>[
          Container(
              padding: EdgeInsets.fromLTRB(17.0, 1.0, 7.0, 1.0),
              child: Row(
                children: <Widget>[],
              )),
          Expanded(
            child: FutureBuilder<List<ParseObject>>(
                future: getTodo(),
                builder: (context, snapshot) {
                  switch (snapshot.connectionState) {
                    case ConnectionState.none:
                    case ConnectionState.waiting:
                      return Center(
                        child: Container(
                            width: 100,
                            height: 100,
                            child: CircularProgressIndicator()),
                      );
                    default:
                      if (snapshot.hasError) {
                        return Center(
                          child: Text("Error..."),
                        );
                      }
                      if (!snapshot.hasData) {
                        return Center(
                          child: Text("No Data..."),
                        );
                      } else {
                        return ListView.builder(
                            padding: EdgeInsets.only(top: 10.0),
                            // reverse: true,
                            itemCount:
                                //1,
                                snapshot.data!.length,
                            itemBuilder: (context, index) {
                              //*************************************
                              //Get Parse Object Values
                              //*************************************
                              //Get Parse Object Values
                              final varTodo = snapshot.data![index];
                              final varNote = varTodo.get<String>('Notes')!;
                              final varAmount =
                                  varTodo.get<String>('TransferAmount')!;
                              final varDep = varTodo.get<String>('Department')!;
                              final varNoti = varTodo.get<String>('NotiType')!;

                              numOfRows = snapshot.data!.length;
                              //*************************************    //*************************************

                              return Container(
                                width: MediaQuery.of(context).size.width,
                                child: ListTile(
                                  title: SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Container(
                                          padding: EdgeInsets.only(
                                              left: 5, right: 5),
                                          child: Text(
                                            varNoti,
                                            style: TextStyle(
                                                color: Color(0xff0a0909),
                                                fontSize: 20),
                                          ),
                                        ),
                                        Container(
                                          padding: EdgeInsets.only(
                                              left: 5, right: 15),
                                          child: Text(
                                            "نوع العملية",
                                            style: TextStyle(
                                                color: Color(0xff62d758),
                                                fontSize: 20),
                                          ),
                                        ),
                                        Container(
                                          decoration: BoxDecoration(
                                              color: Color(0xff323ee8),
                                              border: Border.all(
                                                color: Color(0xff05080f),
                                                width: 0.7,
                                              ),
                                              borderRadius: BorderRadius.only(
                                                topRight: Radius.circular(13),
                                                topLeft: Radius.circular(13),
                                                bottomLeft: Radius.circular(13),
                                                bottomRight:
                                                    Radius.circular(13),
                                              ) //                 <--- border radius here
                                              ),
                                          // color: Color(0xff387ce5),
                                          padding: EdgeInsets.only(
                                              left: 5, right: 5),
                                          child: TextButton(
                                            onPressed: () {},
                                            child: Text(
                                              "عرض",
                                              style: TextStyle(
                                                  color: Colors.white),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  //check(varTitle),
                                  //Text(varTitle),
                                  leading: Container(
                                    // width:
                                    //     MediaQuery.of(context).size.width - 177,
                                    padding: EdgeInsets.only(left: 5),
                                    child: SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                              padding: EdgeInsets.only(left: 5),
                                              child: Text(
                                                varAmount,
                                                style: TextStyle(
                                                    color: Color(0xff080808),
                                                    fontSize: 20),
                                              )),
                                          Container(
                                              padding: EdgeInsets.only(left: 5),
                                              child: Text("المبلغ:",
                                                  style: TextStyle(
                                                      color: Colors.green,
                                                      fontSize: 20))),
                                          SizedBox(width: 4),
                                          Container(
                                              padding: EdgeInsets.only(left: 5),
                                              child: Text(
                                                varDep,
                                                style: TextStyle(
                                                    color: Color(0xff000000),
                                                    fontSize: 20),
                                              )),
                                          Container(
                                            padding: EdgeInsets.only(left: 5),
                                            child: Text(
                                              "الجهة:",
                                              style: TextStyle(
                                                  color: Color(0xff7c092f),
                                                  fontSize: 20),
                                            ),
                                          ),
                                          SizedBox(width: 4),
                                        ],
                                      ),
                                    ),
                                  ),
                                  trailing:
                                      Icon(Icons.money, color: Colors.green),
                                ),
                              );
                            });
                      }
                  }
                }),
          ),
        ],
      ),
    );
  }

  Future<void> saveTodo(String title) async {
    final todo = ParseObject('Report')
      ..set('title', title)
      ..set('done', false);
    await todo.save();
  }

  Future<List<ParseObject>> getTodo() async {
    QueryBuilder<ParseObject> queryTodo =
        QueryBuilder<ParseObject>(ParseObject('Missings'));
    final ParseResponse apiResponse = await queryTodo.query();

    if (apiResponse.success && apiResponse.results != null) {
      return apiResponse.results as List<ParseObject>;
    } else {
      return [];
    }
  }

  Future<void> updateTodo(String id, bool done) async {
    await Future.delayed(Duration(seconds: 1), () {});
  }

  Future<void> deleteTodo(String id) async {
    var todo = ParseObject('Report')..objectId = id;
    await todo.delete();
  }

  check(varTitle) {
    if (varTitle.toString() == "aa")
      return Text("yummy");
    else
      return Text("yak");
  }
} // Class _Todo ends here
