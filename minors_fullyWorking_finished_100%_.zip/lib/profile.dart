// ignore_for_file: prefer_const_constructors

import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

// ignore_for_file: prefer_const_constructors

import 'dart:async';

import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:minors/RecordMissingDetails.dart';
import 'package:minors/main.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import 'RecordMissing.dart';
import 'contactus.dart';
import 'exit.dart';
import 'profile.dart';
import 'royalOrder.dart';
import 'userPage.dart';

const List<String> firstList = <String>[
  '...اختر...',
];

const List<String> yearsList = <String>[
  '...اختر...',
  '2015',
  '2016',
  '2017',
  '2018',
  '2019',
  '2020',
  '2021',
  '2022',
];

const List<String> notiTypeList = <String>[
  '...اختر...',
  'تحويل نقدي',
  'افصاح ',
];

String? department;
String? year;
String? notiType;
String? transferNum;
String? phoneNum;
String? emailAdd;
String? transferAmount;
String? transferedToDep;
//String? note;

File? uploadedImage;
String? moneyTransfer;

int numOfRows = 0;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
/*
  final keyApplicationId = '9XglgwXJxUZdUyIRD0EzrYy7s5bsaRFXlIU7RSzT';
  final keyClientKey = 'DNcLbgsWWNqhCS3VuC9pH4qSInr1xCtLIsSBn39N';
  final keyParseServerUrl = 'https://parseapi.back4app.com';

  await Parse().initialize(keyApplicationId, keyParseServerUrl,
      clientKey: keyClientKey, debug: true);
*/
  final keyApplicationId = '9XglgwXJxUZdUyIRD0EzrYy7s5bsaRFXlIU7RSzT';
  final keyClientKey = 'DNcLbgsWWNqhCS3VuC9pH4qSInr1xCtLIsSBn39N';
  final keyParseServerUrl = 'https://parseapi.back4app.com';

  await Parse().initialize(keyApplicationId, keyParseServerUrl,
      clientKey: keyClientKey, debug: true);
  runApp(MaterialApp(
    home: ProfileBody(),
  ));
}

class Profile extends StatelessWidget {
  // This widget is the root of your application.
  //
/*
  Profile(
    notes,
    varDepartment,
  );
  */

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Stateful Clicker Counter',
      theme: ThemeData(
        // Application theme data, you can set the colors for the application as
        // you want
        primarySwatch: Colors.grey,
      ),
      home: ProfileBody(),
    );
  }
}

class ProfileBody extends StatefulWidget {
  @override
  _ProfileBodyState createState() => _ProfileBodyState();
}

class _ProfileBodyState extends State<ProfileBody> {
  final todoController = TextEditingController();
  List<ParseObject> results = <ParseObject>[];
  final GlobalKey<FormState> _Formkey = GlobalKey<FormState>();
  //bool isVisible = false;

  final todoController2 = TextEditingController();
  final todoControllerNote = TextEditingController();
  final todoControllerTransferAmount = TextEditingController();
  final todoControllerTransferNum = TextEditingController();
  final todoControllerDepTo = TextEditingController();
  final todoControllerMobileNum = TextEditingController();
  final todoControllerName = TextEditingController();
  final todoControllerTheID = TextEditingController();
  final todoControllerIdType = TextEditingController();
  final todoControllerEmail = TextEditingController();

  //todoControllerDepTo  todoControllerMobileNum

  //List<ParseObject> results = <ParseObject>[];
  String dropdownValue = '...اختر...';
  String dropdownValue2 = '...اختر...';
  String dropdownValue3 = '...اختر...';
  String dropdownValue4 = '...اختر...';
  String dropdownValue5 = '...اختر...';
  String dropdownValue6 = '...اختر...';
  String dropdownValue7 = '...اختر...';

  //String dropdownValue = yearsList.first;
  List<ParseObject?> dropdownItems = <ParseObject?>[];

  //FilePickerResult? result;
  //String? _fileName;
  //PlatformFile? pickedFile;
  //bool isLoading = false;
  //File? fileToDisplay;
  //bool isVisible = true;
  //final GlobalKey<FormState> _Formkey = GlobalKey<FormState>();
  //

  //List<ParseObject> results = <ParseObject>[];
  //
  //String dropdownValue = yearsList.first;
  //List<ParseObject?> dropdownItems = <ParseObject?>[];

  FilePickerResult? result;
  String? _fileName;
  PlatformFile? pickedFile;
  bool isLoading = false;
  File? fileToDisplay;
  bool isVisible = true;
  //final GlobalKey<FormState> _Formkey = GlobalKey<FormState>();
  //
  //

  void readData() async {
    var apiResponse = await ParseObject('Todo').getAll();
    if (apiResponse.success) {
      for (var myObject in apiResponse.result) {
        debugPrint(" OBJECT: " + myObject.get<String>('Department')!);
        print("yay ");
        dropdownItems.add(myObject);
      }
      setState(() {});
    } else {
      print("can't connect to DB ");
    }
    @override
    void initState() {
      super.initState();
      readData();
      print("barb is kokay");
    }
  }

  void PickFile() async {
    try {
      setState(() {
        isLoading = true;
      });

      result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['png', 'pdf', 'jpg', 'xlsx'],
        allowMultiple: false,
      );

      if (result != null) {
        _fileName = result!.files.first.name;
        pickedFile = result!.files.first;
        fileToDisplay = File(pickedFile!.path.toString());

        print("FileName: $_fileName");
      }
      setState(() {
        isLoading = false;
      });
    } catch (e) {
      print(e);
    }
  }

  void addToDo() async {
    if (todoController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Empty title"),
        duration: Duration(seconds: 2),
      ));
      return;
    }
    await saveTodo(todoController.text);
    setState(() {
      todoController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    double widthSize = MediaQuery.of(context).size.width;
    double heightSize = MediaQuery.of(context).size.height;
    String selectText = "اختر";

    return Container(
      // height: 1777,
      width: MediaQuery.of(context).size.width,
      child: Scaffold(
          appBar: AppBar(
            foregroundColor: Color(0xff000000),
            title: Text("قائمة البلاغات"),
            backgroundColor: Color(0xffffffff),
            leading: Padding(
              padding: const EdgeInsets.only(left: 0.8),
              child: IconButton(
                icon: Icon(
                  Icons.home,
                  color: Color(0xff000000),
                  size: 30.0,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomePage()),
                  );
                },
              ),
            ),
            centerTitle: true,
          ),
          body: SingleChildScrollView(
            child: Column(children: <Widget>[
              // here is the start of the body Column Container
              // // here is start end of the body Column Container
              // // here is the start of the body Column Container
              // // here is the start of the body Column Container
              // // here is the start of the body Column Container
              // // here is the start of the body Column Container
              // // here is the start of the body Column Container
              // // here is the start of the body Column Container
              //

              Column(
                // mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Form(
                    child: Container(
                      margin: EdgeInsets.only(top: 22),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                        topRight: Radius.circular(73),
                        topLeft: Radius.circular(13),
                        bottomRight: Radius.circular(73),
                        bottomLeft: Radius.circular(13),
                      )),
                      width: widthSize,
                      child: Column(
                        // fit: StackFit.passthrough,
                        //alignment: Alignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: widthSize,
                            // height: 588,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                topRight: Radius.circular(23),
                                topLeft: Radius.circular(23),
                                bottomLeft: Radius.circular(0),
                                bottomRight: Radius.circular(0),
                              ),
                            ),
                            // color: Colors.white,
                          ),

                          // above is the end of the first muliti Select Field row container
                          // above is the end of the last muliti Select Field  row container
                          //
                          //
                          //
                          /// body white container starts here
                          Container(
                            color: Colors.white,
                            padding: EdgeInsets.all(17),
                            width: widthSize - 35,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              textDirection: TextDirection.rtl,
                              children: [
                                ///
                                ///
                                ///
                                ///
                                ///

                                Container(
                                  padding: EdgeInsets.all(17),
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    "  الاسم ",
                                    textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),

                                Container(
                                  alignment: Alignment.center,
                                  // margin: EdgeInsets.only(top: 7),
                                  width: widthSize - 68,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Colors.transparent,
                                      width: 0.7,
                                    ),
                                    // color: Colors.white,
                                    color: Color(0xffdcdbdb),

                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(27),
                                      topLeft: Radius.circular(27),
                                      bottomLeft: Radius.circular(17),
                                      bottomRight: Radius.circular(17),
                                    ),
                                  ),
                                  child: TextFormField(
                                    enabled: false,
                                    controller: todoControllerName,
                                    onChanged: (value7) {
                                      setState(() {
                                        print(value7);
                                        value7 = todoControllerNote.text;
                                        note = value7;
                                        print("kooooooooooo");
                                      });
                                      print(value7 +
                                          " This is the note TextField ");
                                    },
                                    textAlign: TextAlign.right,
                                    textDirection: TextDirection.rtl,
                                    decoration: InputDecoration(
                                        hintTextDirection: TextDirection.rtl,
                                        alignLabelWithHint: false,
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(17),
                                            topLeft: Radius.circular(17),
                                            bottomLeft: Radius.circular(17),
                                            bottomRight: Radius.circular(17),
                                          ),
                                        ),
                                        labelText: 'داوود',
                                        labelStyle: TextStyle(
                                          color: Color(0xff000000),
                                        )),
                                  ),
                                ),

                                /// Name ends here
                                ///  /// Name ends here
                                ///  /// Naame ends here

                                Container(
                                  padding: EdgeInsets.all(17),
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    "  نوع الهوية ",
                                    textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),

                                Container(
                                  alignment: Alignment.center,
                                  // margin: EdgeInsets.only(top: 7),
                                  width: widthSize - 68,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Colors.transparent,
                                      width: 0.7,
                                    ),
                                    color: Color(0xffdcdbdb),
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(17),
                                      topLeft: Radius.circular(17),
                                      bottomLeft: Radius.circular(17),
                                      bottomRight: Radius.circular(17),
                                    ),
                                  ),
                                  child: TextFormField(
                                    enabled: false,
                                    controller: todoControllerIdType,
                                    onChanged: (value7) {
                                      setState(() {
                                        print(value7);
                                        value7 = todoControllerNote.text;
                                        note = value7;
                                        print("kooooooooooo");
                                      });
                                      print(value7 +
                                          " This is the note TextField ");
                                    },
                                    textAlign: TextAlign.center,
                                    textDirection: TextDirection.rtl,
                                    decoration: InputDecoration(
                                        alignLabelWithHint: true,
                                        hintTextDirection: TextDirection.rtl,
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(17),
                                            topLeft: Radius.circular(17),
                                            bottomLeft: Radius.circular(17),
                                            bottomRight: Radius.circular(17),
                                          ),
                                        ),
                                        labelText: 'هوية مواطن ',
                                        labelStyle: TextStyle(
                                            color: Color(0xff000000))),
                                  ),
                                ),
                                //Id Type is above

                                //Id Type is above
                                //  //Id Type is above
                                //  //Id Type is above
                                //
                                Container(
                                  padding: EdgeInsets.all(17),
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    "  الهوية ",
                                    textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),

                                Container(
                                  alignment: Alignment.center,
                                  // margin: EdgeInsets.only(top: 7),
                                  width: widthSize - 68,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Colors.transparent,
                                      width: 0.7,
                                    ),
                                    color: Color(0xffdcdbdb),
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(17),
                                      topLeft: Radius.circular(17),
                                      bottomLeft: Radius.circular(17),
                                      bottomRight: Radius.circular(17),
                                    ),
                                  ),
                                  child: TextFormField(
                                    enabled: false,
                                    controller: todoControllerTheID,
                                    onChanged: (value7) {
                                      setState(() {
                                        print(value7);
                                        value7 = todoControllerNote.text;
                                        note = value7;
                                        print("kooooooooooo");
                                      });
                                      print(value7 +
                                          " This is the note TextField ");
                                    },
                                    textAlign: TextAlign.center,
                                    textDirection: TextDirection.rtl,
                                    decoration: InputDecoration(
                                        alignLabelWithHint: true,
                                        hintTextDirection: TextDirection.rtl,
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(17),
                                            topLeft: Radius.circular(17),
                                            bottomLeft: Radius.circular(17),
                                            bottomRight: Radius.circular(17),
                                          ),
                                        ),
                                        labelText: '1102222591  ',
                                        labelStyle: TextStyle(
                                            color: Color(0xff000000))),
                                  ),
                                ),
                                //Id Type is above

                                //Id Type is above
                                //  //Id Type is above
                                //  //Id Type is above
                                //

                                Container(
                                  padding: EdgeInsets.all(17),
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    "  مفوض لجهة ",
                                    textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),

                                Container(
                                  alignment: Alignment.center,
                                  // margin: EdgeInsets.only(top: 7),
                                  width: widthSize - 68,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Colors.transparent,
                                      width: 0.7,
                                    ),
                                    color: Colors.white,
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(17),
                                      topLeft: Radius.circular(17),
                                      bottomLeft: Radius.circular(17),
                                      bottomRight: Radius.circular(17),
                                    ),
                                  ),
                                  child: TextFormField(
                                    // enabled: false,
                                    controller: todoControllerDepTo,
                                    onChanged: (value10) {
                                      transferedToDep = value10;
                                      setState(() {
                                        print(value10);
                                        value10 = todoControllerNote.text;
                                        //transferedToDep = value10;

                                        print("kooooooooooo");
                                      });
                                      print(value10 +
                                          " This is the Value10 TextField ");
                                    },
                                    textAlign: TextAlign.center,
                                    textDirection: TextDirection.rtl,
                                    decoration: InputDecoration(
                                        alignLabelWithHint: true,
                                        hintTextDirection: TextDirection.rtl,
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(17),
                                            topLeft: Radius.circular(17),
                                            bottomLeft: Radius.circular(17),
                                            bottomRight: Radius.circular(17),
                                          ),
                                        ),
                                        labelText: '        اسم الجهة ',
                                        labelStyle: TextStyle(
                                            color: Color(0xff000000))),
                                  ),
                                ),
                                //Id Type is above

                                //Id Type is above
                                //  //Id Type is above
                                //  //Id Type is above
                                //
                                Container(
                                  padding: EdgeInsets.all(17),
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    "  رقم الجوال ",
                                    textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),

                                Container(
                                  alignment: Alignment.center,
                                  // margin: EdgeInsets.only(top: 7),
                                  width: widthSize - 68,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Colors.transparent,
                                      width: 0.7,
                                    ),
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(17),
                                      topLeft: Radius.circular(17),
                                      bottomLeft: Radius.circular(17),
                                      bottomRight: Radius.circular(17),
                                    ),
                                  ),
                                  child: TextFormField(
                                    // enabled: false,
                                    controller: todoControllerMobileNum,
                                    onChanged: (value8) {
                                      phoneNum = value8;
                                      setState(() {
                                        print(value8);
                                        value8 = todoControllerMobileNum.text;

                                        print("kooooooooooo");
                                      });
                                    },
                                    textAlign: TextAlign.center,
                                    textDirection: TextDirection.rtl,
                                    decoration: InputDecoration(
                                        alignLabelWithHint: true,
                                        hintTextDirection: TextDirection.rtl,
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(17),
                                            topLeft: Radius.circular(17),
                                            bottomLeft: Radius.circular(17),
                                            bottomRight: Radius.circular(17),
                                          ),
                                        ),
                                        labelText: ' 05xxxxxxxx ',
                                        labelStyle: TextStyle(
                                            color: Color(0xff000000))),
                                  ),
                                ),
                                //Id Type is above

                                //Id Type is above
                                //  //Id Type is above
                                //  //Id Type is above
                                //

                                Container(
                                  padding: EdgeInsets.all(17),
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    "  البريد الأكتروني ",
                                    textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),

                                Container(
                                  alignment: Alignment.center,
                                  // margin: EdgeInsets.only(top: 7),
                                  width: widthSize - 68,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Colors.transparent,
                                      width: 0.7,
                                    ),
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(17),
                                      topLeft: Radius.circular(17),
                                      bottomLeft: Radius.circular(17),
                                      bottomRight: Radius.circular(17),
                                    ),
                                  ),
                                  child: TextFormField(
                                    // enabled: false,
                                    controller: todoControllerEmail,
                                    onChanged: (value8) {
                                      emailAdd = value8;
                                      setState(() {
                                        print(value8);
                                        value8 = todoControllerEmail.text;
                                        // note = value8;
                                        emailAdd = value8;
                                        print("kooooooooooo");
                                      });
                                      print(value8 +
                                          " This is the note TextField ");
                                    },
                                    textAlign: TextAlign.center,
                                    textDirection: TextDirection.rtl,
                                    decoration: InputDecoration(
                                        alignLabelWithHint: true,
                                        hintTextDirection: TextDirection.rtl,
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(17),
                                            topLeft: Radius.circular(17),
                                            bottomLeft: Radius.circular(17),
                                            bottomRight: Radius.circular(17),
                                          ),
                                        ),
                                        labelText: 'البريد الاكتروني  ',
                                        labelStyle: TextStyle(
                                            color: Color(0xff000000))),
                                  ),
                                ),
                                //Id Type is above

                                //Id Type is above
                                //  //Id Type is above
                                //  //Id Type is above
                                Container(
                                  margin: EdgeInsets.only(
                                      left: 12, top: 22, bottom: 12),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          height: 37,
                                          width: 62,
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              color: Colors.grey,
                                              width: 0.7,
                                            ),
                                            color: Color(0xff038447),
                                            borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(17),
                                              topLeft: Radius.circular(17),
                                              bottomLeft: Radius.circular(17),
                                              bottomRight: Radius.circular(17),
                                            ),
                                          ),
                                          alignment: Alignment.center,
                                          margin: EdgeInsets.only(top: 12),
                                          //color: Color(0xff038447),
                                          child: TextButton(
                                              onPressed: () async {
                                                print(
                                                    "transferToDep is $transferedToDep");
                                                print("emailAd is $emailAdd");
                                                print("PhoneNum is $phoneNum");
                                                if (transferedToDep == null ||
                                                    transferedToDep == "" ||
                                                    emailAdd == null ||
                                                    emailAdd == "" ||
                                                    phoneNum == null ||
                                                    phoneNum == "") {
                                                  ScaffoldMessenger.of(context)
                                                      .showSnackBar(SnackBar(
                                                    content: Stack(
                                                      children: [
                                                        Align(
                                                          alignment: Alignment
                                                              .bottomCenter,
                                                          child: Container(
                                                            padding:
                                                                EdgeInsets.only(
                                                              top: 37,
                                                              right: 27,
                                                              left: 17,
                                                            ),
                                                            height: 127,
                                                            width:
                                                                MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width,
                                                            decoration: BoxDecoration(
                                                                color: Color(
                                                                    0xFFC72C41),
                                                                borderRadius: BorderRadius
                                                                    .all(Radius
                                                                        .circular(
                                                                            20))),
                                                            child: Column(
                                                              children: [
                                                                Text(
                                                                  " !! خطأ  ",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          17,
                                                                      color: Colors
                                                                          .yellowAccent),
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  maxLines: 2,
                                                                ),
                                                                Text(
                                                                    "  يوجد حقول فارغة "),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: 147,
                                                          bottom: 67,
                                                          //-57,
                                                          child: Container(
                                                            height: 112,
                                                            width: 77,
                                                            child: Image.asset(
                                                                "images/eyesRemoveBG.png"),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: 27,
                                                          bottom: 62,
                                                          //-57,
                                                          child: Container(
                                                            height: 172,
                                                            width: 77,
                                                            child: Image.asset(
                                                                "images/refHopeSo.png",
                                                                scale: 0.7),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    behavior: SnackBarBehavior
                                                        .floating,
                                                    backgroundColor:
                                                        Colors.transparent,
                                                    elevation: 0,
                                                  ));
                                                  print("empty");
                                                } else {
                                                  ScaffoldMessenger.of(context)
                                                      .showSnackBar(SnackBar(
                                                    content: Stack(
                                                      children: [
                                                        Align(
                                                          alignment: Alignment
                                                              .bottomCenter,
                                                          child: Container(
                                                            padding:
                                                                EdgeInsets.only(
                                                              top: 37,
                                                              right: 27,
                                                              left: 17,
                                                            ),
                                                            height: 127,
                                                            width:
                                                                MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width,
                                                            decoration: BoxDecoration(
                                                                color: Colors
                                                                    .green,
                                                                borderRadius: BorderRadius
                                                                    .all(Radius
                                                                        .circular(
                                                                            20))),
                                                            child: Column(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: const [
                                                                Text(
                                                                  "  ",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          17,
                                                                      color: Colors
                                                                          .redAccent),
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  maxLines: 2,
                                                                ),
                                                                Text(
                                                                    "    تم التحديث بنجاح "),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: 147,
                                                          bottom: 67,
                                                          //-57,
                                                          child: Container(
                                                            height: 112,
                                                            width: 77,
                                                            child: Image.asset(
                                                                "images/clapping.gif"),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: 27,
                                                          //77,

                                                          bottom: 27,
                                                          //-57,
                                                          child: Container(
                                                            height: 172,
                                                            width: 77,
                                                            child: Image.asset(
                                                                "images/like.gif",
                                                                scale: 0.7),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    behavior: SnackBarBehavior
                                                        .floating,
                                                    backgroundColor:
                                                        Colors.transparent,
                                                    elevation: 0,
                                                  ));
                                                  updateTodo(
                                                    'nQfi97uAu7',
                                                    phoneNum!,
                                                    emailAdd!,
                                                    transferedToDep!,
                                                  );
                                                }
                                              },
                                              child: Text(
                                                "تحديث",
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              )),
                                        ),
                                      ]),
                                ),

                                // the horizantal ListView is below
                                // // the horizantal ListView is below
                                // // the horizantal ListView is below
                                // // the horizantal ListView is below

                                //// here is the conent ends
                                /// here is the conent ends
                                /// here is the conent ends
                                /// here is the conent ends
                                /// here is the conent ends
                                /// here is the conent ends
                                /// here is the conent ends
                                /// here is the conent ends
                                /// here is the conent ends
                                ///

                                // 3

                                // 4

                                // 6

                                // 6
                                // 9
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Colors.transparent,
                                      width: 0.7,
                                    ),
                                    color: Color(0xf2d7d5d5),
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(17),
                                      topLeft: Radius.circular(17),
                                      bottomLeft: Radius.circular(0),
                                      bottomRight: Radius.circular(0),
                                    ),
                                  ),
                                  //   color: Color(0xf2d7d5d5),
                                  padding: EdgeInsets.only(
                                      top: 10,
                                      left: 2.00,
                                      right: 2,
                                      bottom: 10),
                                  alignment: Alignment.center,
                                  child: Text(
                                      "  الهيئة العامة للولاية على أموال القاصرين ومن في حكمهم @  "),
                                ),

                                Container(
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Colors.transparent,
                                      width: 0.7,
                                    ),
                                    color: Color(0xf2d7d5d5),
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(0),
                                      topLeft: Radius.circular(0),
                                      bottomLeft: Radius.circular(17),
                                      bottomRight: Radius.circular(17),
                                    ),
                                  ),
                                  // color: Color(0xf2d7d5d5),
                                  margin: EdgeInsets.only(top: 0),
                                  alignment: Alignment.center,
                                  child: Text("  2022"),
                                ),
                                // the parent column ends below
                                // the parent column ends below

                                // the column end below is for the white background column
                                //  // the column below is the white background column
                                //  // the column below is the white background column
                              ],
                            ),
                          ),

                          // sliverBox ends here
                        ],
                      ),
                    ),
                  ),
                ],
              ),

              // here is the end of the body Column Container
              // // here is the end of the body Column Container
              // // here is the end of the body Column Container
              // // here is the end of the body Column Container
              // // here is the end of the body Column Container
              // // here is the end of the body Column Container
              // // here is the end of the body Column Container
              // // here is the end of the body Column Container
            ]),
          )),
    );
  } // Widget Build context ends here

  Future<void> saveTodo(String title) async {
    final todo = ParseObject('Missings')
      ..set('title', title)
      ..set('done', false);
    await todo.save();
  }

  Future<List<ParseObject>> getTodo() async {
    QueryBuilder<ParseObject> queryTodo =
        QueryBuilder<ParseObject>(ParseObject('Missings'));
    final ParseResponse apiResponse = await queryTodo.query();

    if (apiResponse.success && apiResponse.results != null) {
      return apiResponse.results as List<ParseObject>;
    } else {
      return [];
    }
  }

  Future<void> updateTodo(
      String id, String done, String email, String transferedToDep) async {
    var todo = ParseObject('Missings')
      ..objectId = id
      ..set('PhoneNumber', done)
      ..set('Department', transferedToDep)
      ..set('Email', email);
    await todo.save();
  }

  Future<void> deleteTodo(String id) async {
    var todo = ParseObject('Todo')..objectId = id;
    await todo.delete();
  }

  check(varTitle) {
    if (varTitle.toString() == "aa")
      return Text("yummy");
    else
      return Text("yak");
  }
} // Class _Todo ends here
