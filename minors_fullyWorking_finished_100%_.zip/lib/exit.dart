//import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:minors/Todo.dart';
import 'package:minors/contactus.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:url_launcher/link.dart';
import 'package:url_launcher/url_launcher.dart';
import 'RecordMissing.dart';

import 'connectToDBCode.dart';
import 'main.dart';
import 'userPage.dart';

class ExitPage extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Stateful Clicker Counter',
      theme: ThemeData(
        // Application theme data, you can set the colors for the application as
        // you want
        primarySwatch: Colors.grey,
      ),
      home: MyHomePage(title: 'Flutter Demo Clicker Counter Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final String title;
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<ParseObject> results = <ParseObject>[];

  @override
  Widget build(BuildContext context) {
    // String emailFirst = "munaif.abdulaziz@wilayah.gov.sa";
    // String secondEmail = "anqari.sulaiman@wilayah.gov.sa";
    // String thirdEmail = "alharby.abdulaziz@wilayah.gov.sa";
    double widthSize = MediaQuery.of(context).size.width;
    double heightSize = MediaQuery.of(context).size.height;

    setState(() {
      Future.delayed(Duration(milliseconds: 700), () {
        // Do something

        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => HomePage()),
        );
      });
    });

    return Scaffold(
      backgroundColor: Colors.white,
      //Color(0xff493636),
      //Color(0xf2f6f4f4),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              backgroundColor: Color(0xffffffff),
              leadingWidth: 72,
              leading: Padding(
                padding: const EdgeInsets.only(left: 0.8),
                child: IconButton(
                  icon: Icon(
                    Icons.person,
                    color: Colors.black,
                    size: 30.0,
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ExitPage()),
                    );
                  },
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.only(right: 8.0),
                child: Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(top: 0.2),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          // topRight: Radius.circular(73),
                          // topLeft: Radius.circular(13),
                          )),
                  width: widthSize,
                  child: Column(

                      // fit: StackFit.passthrough,
                      //alignment: Alignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(1.0),
                          child: Text("الخروج",
                              style: TextStyle(
                                  fontSize: 27,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xff01183f))),
                        ),
                        Container(
                          width: 357,
                          height: 477,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                topRight: Radius.circular(73),
                                topLeft: Radius.circular(53),
                              )),
                          child: Image.asset(
                            'images/Exit.png',
                          ),

                          //Image.network(
                          // "https://media.giphy.com/media/7DzlajZNY5D0I/giphy.gif"),
                        ),
                        // above is the end of the last image row container
                        // above is the end of the last image row container
                        //
                        //

// here
// here
// here
// here
// here

                        Container(
                          margin: EdgeInsets.only(top: 77),
                          alignment: Alignment.center,
                          child: Text(
                              "  الهيئة العامة للولاية على أموال القاصرين ومن في حكمهم @",
                              style: TextStyle(color: Color(0xff878687))),
                        ),

                        Container(
                          margin: EdgeInsets.only(top: 2),
                          alignment: Alignment.center,
                          child: Text(
                            "  2022",
                            style: TextStyle(color: Color(0xff878687)),
                          ),
                        ),
                        // the parent column ends below
                        // the parent column ends below
                      ]),
                ),
              ),
            ),
          ],
        ),
      ),

////////////////////////////////////////
// the endDrawer is below
///////////////////////////////////////
      endDrawer: Container(
        padding: EdgeInsets.only(top: 7, left: 7, right: 7),
        child: Drawer(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Image.asset("images/title.JPG"),
              Container(
                width: widthSize - 35,
                height: 77,
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(
                      color: Colors.transparent,
                      width: 0.7,
                    ),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(73),
                      topLeft: Radius.circular(73),
                      bottomLeft: Radius.circular(73),
                      bottomRight: Radius.circular(73),
                    ) //                 <--- border radius here
                    ),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Todo()),
                    );
                  },
                  hoverColor: Color(0xff047c54),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Row(
                            children: [
                              Text(" الرئيسية", style: TextStyle(fontSize: 17)),
                              SizedBox(width: 12),
                              Icon(Icons.home_max_outlined),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                width: widthSize - 35,
                height: 77,
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(
                      color: Colors.transparent,
                      width: 0.7,
                    ),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(73),
                      topLeft: Radius.circular(73),
                      bottomLeft: Radius.circular(73),
                      bottomRight: Radius.circular(73),
                    ) //                 <--- border radius here
                    ),
                child: InkWell(
                  onTap: () {
                    print(varDepartment);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              RecordMissing(notes, varDepartment)),
                    );
                  },
                  hoverColor: Color(0xff047c54),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Row(
                            children: [
                              Text(" تسجيل المفقودات",
                                  style: TextStyle(fontSize: 17)),
                              SizedBox(width: 12),
                              Icon(Icons.person),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              InkWell(
                hoverColor: Color(0xff047c54),
                onTap: () {
                  //print(doQueryByName.toString());
                  print("contact us");

                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ContactusPage()),
                  );
                },
                child: Container(
                  width: widthSize - 35,
                  height: 77,
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Text(" للتواصل والدعم",
                              style: TextStyle(fontSize: 17)),
                          SizedBox(width: 12),
                          Icon(Icons.person),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              Container(
                width: widthSize - 35,
                height: 77,
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(
                      color: Colors.transparent,
                      width: 0.7,
                    ),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(73),
                      topLeft: Radius.circular(73),
                      bottomLeft: Radius.circular(73),
                      bottomRight: Radius.circular(73),
                    ) //                 <--- border radius here
                    ),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => UserPage()),
                    );
                  },
                  hoverColor: Color(0xff047c54),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Row(
                            children: [
                              Text(" دليل المستخدم",
                                  style: TextStyle(fontSize: 17)),
                              SizedBox(width: 12),
                              Icon(Icons.person),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              /// userData is above and it's ending here
              /// /// userData is above and it's ending here
              /// /// userData is above and it's ending here
              Container(
                width: widthSize - 35,
                height: 77,
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(
                      color: Colors.transparent,
                      width: 0.7,
                    ),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(73),
                      topLeft: Radius.circular(73),
                      bottomLeft: Radius.circular(73),
                      bottomRight: Radius.circular(73),
                    ) //                 <--- border radius here
                    ),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ExitPage()),
                    );
                  },
                  hoverColor: Color(0xff047c54),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Row(
                            children: [
                              Text(" الأمر السامي",
                                  style: TextStyle(fontSize: 17)),
                              SizedBox(width: 12),
                              Icon(Icons.person),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                width: widthSize - 35,
                height: 77,
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(
                      color: Colors.transparent,
                      width: 0.7,
                    ),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(73),
                      topLeft: Radius.circular(73),
                      bottomLeft: Radius.circular(73),
                      bottomRight: Radius.circular(73),
                    ) //                 <--- border radius here
                    ),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ExitPage()),
                    );
                  },
                  hoverColor: Color(0xff047c54),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 22.0, right: 52, bottom: 22),
                    child: Container(
                      width: widthSize - 35,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Row(
                            children: [
                              Text(" تسجيل خروج",
                                  style: TextStyle(fontSize: 17)),
                              SizedBox(width: 12),
                              Icon(Icons.logout),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),

      /// the endDrawer ends above
      /// the endDrawer ends above
      /// The end drawer ends above

      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
